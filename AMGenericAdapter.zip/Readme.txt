UCMDB to AM Generic Adapter
=======================

I	Name: AMGenericAdapter.zip
	Version: 1.05
	Package ID: 0250

II. 	Description
	This adapter can be used to push and populate data between UCMDB and AM.

III. 	How to Use
	See the Asset Manager Generic Adapter User Guide.

IV. 	This integration supports:
	Universal CMDB version 10.20 and later.
