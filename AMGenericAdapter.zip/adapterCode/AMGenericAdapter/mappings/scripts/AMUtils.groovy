package mappings.scripts

import com.hp.amadapter.push.structure.AMVersionInfo

public class AMUtils {

    // Multi-Tenant Configuration
    public static final boolean ENABLE_PUSH_MT = false;
    public static final boolean ENABLE_POP_MT = false;
    public static Map<String, String> mtMapForPop = new HashMap<String, String>();
    public static Map<String, String> mtMapForPush = new HashMap<String, String>();    
    static {
	
		/** put AM Tenant Code and UCMDB Tenant Name in below map */
        // mtMapForPop.put("AMTENANT1", "UCMDBTENANT1");
        // mtMapForPop.put("AMTENANT2", "UCMDBTENANT2");
		
        // mtMapForPush.put("UCMDBTENANT1", "AMTENANT1");
        // mtMapForPush.put("UCMDBTENANT2", "AMTENANT2");

    }

    public static int boolToInt(def bool){
        if(isNull(bool) || !bool){
            return 0;
        }
        return 1;
    }

    public static String uCase(String str) {
        if (isNull(str)) {
            return null;
        }
        return str.toUpperCase();
    }

    public static String ExtractValue(String str, String separator) {
        int startIndex = str.indexOf(separator);
        if (startIndex != -1) {
            return str.substring(startIndex + 1, str.length());
        }
        return str;
    }

// returns true if 'src' contains at least one of the values[]
    public static boolean fisContainOne(def src, def ... values) {
        if (isNull(src)) {
            return false;
        }
        for (String str: values) {
            if (!isNull(str) && src.contains(str)) {
                return true;
            }
        }
        return false;
    }

    public static boolean fIsContainList(def listVal, def containValue) {
        if (isNull(containValue)) {
            return false;
        }
        for (String str: listVal) {
            if (!isNull(str) && str.contains(containValue)) {
                return true;
            }
        }
        return false;
    }

    public static def sum(List varList) {
        def sum = 0;
        for (n in varList) {
            if(fIsEmpty(n)){
                n = 0;
            }
            sum += n;
        }
        return sum;
    }

// Returns default value if value is empty
    public static String fCleanValueWithDefault(String strVal, String strDefault) {
        String retVal;
        if (fIsEmpty(strVal)) {
            retVal = strDefault;
        }
        else {
            retVal = strVal;
        }
        return retVal;
    }

    public static String rightPart(String str, String separator) {
        if (fIsEmpty(str)) {
            return null;
        }
        int startIndex = str.indexOf(separator);
        if (startIndex != -1) {
            return str.substring(startIndex + 1);
        }
        return null;
    }

    public static String leftPart(String str, String separator) {
        if (fIsEmpty(str)) {
            return "";
        }
        int endIndex = str.lastIndexOf(separator);
        if (endIndex != -1) {
            return str.substring(0, endIndex);
        }
        return "";
    }

    public static def getLowestValue(List list) {
        if (!isNull(list) && list.size() > 0) {
            list.sort();
            // we want to avoid from returning null values if there are non null in the list.
            for(n in list){
                if(!isNull(n)){
                    return n;
                }
            }
        }
        return null;
    }

    public static def getHighestValue(List list){
        def retVal = null;
        if (!isNull(list) && list.size() > 0) {
            list.sort();
            retVal = list.get(list.size()-1);
        }
        return retVal;
    }

    // applies for chooseKey function
    public static def getFirstNotEmpty(def ... listValues) {
        for (def value: listValues) {
            if (!fIsEmpty(value)) {
                return value;
            }
        }
        return null;
    }

    public static boolean isNull(def obj) {
        return obj == null || obj == "null";
    }

    public static boolean fIsEmpty(def str) {
        if (isNull(str) || str.equals("")) {
            return true;
        }
        return false;
    }

    public static boolean fIsEmptyOrZero(def value) {
       return fIsEmpty(value) || value == 0 || value == '0';
       }


    public static Boolean toBoolean(String value) {
        return "1".equals(value) ? true : false;
    }

    public static List<String> toStringList(String value) {
        List<String> values = new ArrayList<String>();
        values.add(value);
        return values;
    }
    
    // Description - This function reformats a source string by capitalizing the first letter of each word.
    public static String toSmart(String str) {
        if(str == null){
            return null;
        }
        String[] strArr = str.split(" ");
        def resStr = "";
        for (int i = 0; i < strArr.length; i++) {
            if (!fIsEmpty(strArr[i])) {
                def upperWord;
                strArr[i] = strArr[i].trim();
                def firstChar = strArr[i].charAt(0);
                if(firstChar.isLetter() && firstChar.isLowerCase()){
                    upperWord = strArr[i].replaceFirst(Character.toString(firstChar), Character.toString(firstChar.toUpperCase()));
                }
                else{
                    upperWord = strArr[i];
                }
                if(i != 0){
                    resStr += " ";
                }
                resStr += upperWord;
            }
        }

        return resStr;
    }

    public static boolean containsIgnoreCase(String str, String value){
        return (!isNull(str) && str.toLowerCase().contains(value.toLowerCase()));
    }

    public static boolean isMatchVersion (String paramAMVersion, String paramSAMVersion ){
      if(fIsEmpty(AMVersionInfo.amVersion))
        return false;
      // AM version is must
      if (!fIsEmpty(paramAMVersion)){
        paramAMVersion = AMVersionInfo.format(paramAMVersion);
        if ((AMVersionInfo.amVersion).compareTo(paramAMVersion) >= 0)
          return true;
      }
      //check if SAM installed.
      if (fIsEmpty(AMVersionInfo.samVersion))
        return false;
        
      if (!fIsEmpty(paramSAMVersion)){
        paramSAMVersion = paramSAMVersion.trim();
        if ("*".equals(paramSAMVersion))
          return true;
        paramSAMVersion = AMVersionInfo.format(paramSAMVersion);
        if (AMVersionInfo.samVersion.compareTo(paramSAMVersion) >= 0){
          return true;
        }
      }
      return false;
    }   

    // This function trim the right part of the String, in order to prevent a case that
    // the String ends with white spaces such as \n or \n.
    public static String trimRight(String strVal){
        if(isNull(strVal)){
            return null;
        }
        int i =  strVal.length()-1;
        while(i>0 && Character.isWhitespace(strVal.charAt(i))){
            i--;
        }
        return strVal.substring(0, i+1);
    }

    /**
     * If dt1 > dt2 return 1.
     * If dt1 < dt2 return -1.
     * If dt1 == dt2 return 0.
     * @param dt1
     * @param dt2
     * @return 0 , 1 or -1
     */
    public static int compareDate(Date dt1, Date dt2) {
        if (dt1 == null && dt2 != null)
            return -1;
        if (dt1 != null && dt2 == null)
            return 1;
        if (dt1 == null && dt2 == null)
            return 0;
        long time1 = dt1.getTime(), time2 = dt2.getTime();
        return time1 > time2 ? 1 : (time1 == time2 ? 0 : -1);
    }

    // in AM9.50 added global id in some tables, this function is for checking if use global id as reconcilication key
    public static Boolean useGlobalId() {
        return isMatchVersion('9.50', null);
    }
	
    //Find first non-zero element in list
    public static def findNonZero(def element_list){
        if (element_list.size() == 0) {
            return null;
        } else {
            element_list -= null;
            if (element_list.size() == 0) {
                return null;
            } else {
                return element_list[0];
            }            
        }
    }
}