package mappings.scripts

import com.hp.amadapter.push.PushDirector
import com.hp.amadapter.push.config.CsvReader
import com.hp.ucmdb.adapters.push.MessageOnlyPushMappingException
import com.hp.ucmdb.federationspi.adapter.logging.DataAdapterLogger
import com.hp.ucmdb.federationspi.data.query.types.EnumEntry
import com.hp.ucmdb.federationspi.data.query.types.ExternalCiId
import com.hp.ucmdb.federationspi.data.query.types.ExternalId
import com.hp.ucmdb.federationspi.data.query.types.ExternalRelationId

import java.text.SimpleDateFormat
import java.util.zip.GZIPInputStream

public class AMPush extends AMUtils {

    public static final int FAILED_MAPPING_CI_ERROR_ID = 410100;
    public static final int WARNING_MAPPING_CI_ERROR_ID = 410101;

    public static final String LMS_DATE_FORMAT = "yyyy-MM-dd_HH:mm:ss";

    public static final String WORK_STATION_CODE = "WKS";
    public static final String MODEL_WORKSTATION_AC50 = "WKS";
    public static final String NET_PRINTER_CODE = "NETPRINTER";
    public static final String COMPUTER_PRINTER_CODE = "C30";
    public static final String ATM_SWITCH_CODE = "ITOPTNETDEV";
    public static final String ROUTER_CODE = "C24";
    public static final String SWITCH_CODE = "ITNETSWITCH";
    public static final String HUB_CODE = "C2";
    public static final String GATEWAY_CODE = "ITNETGATE";
    public static final String MODEM_CODE = "C21";
    public static final String LOAD_BALANCER_CODE = "ITSERVBALA";
    public static final String PDA_CODE = "ITPDAORG";
    public static final String FIREWALL_CODE = "ITNETSECUEQ";
    public static final String NET_DEVICE_CODE = "NETDEV";
    public static final String MODEL_VM_AC50 = "VMCPU";
    public static final String SERVER_CODE = "SERVER";
    public static final String VIRTUALIZATION_SOLARIS_ZONE = "Solaris Zone";
    public static final String MODEL_SOFTWARE_INSTAL_AC50 = "SOFTINS";
    public static final String MODEL_MONITOR_AC50 = "MONIT";
    public static final String MODEL_VMWARE_CLUSTER = "ITCG0002";

    public static final String COMPUTER_TYPE_COMPUTER = "Computer";
    public static final String COMPUTER_TYPE_UNIX_COMPUTER = "Unix computer";
    public static final String COMPUTER_TYPE_WINDOWS_COMPUTER = "Windows computer";
    public static final String COMPUTER_TYPE_SERVER_UNIX_COMPUTER = "Unix server computer";
    public static final String COMPUTER_TYPE_SERVER_WINDOWS_COMPUTER = "Windows server computer";
    public static final String COMPUTER_TYPE_SERVER = "Computer servers";
    public static final String COMPUTER_TYPE_VIRTUAL_MACHINE = "Virtual Machine";
    public static final String COMPUTER_TYPE_FIREWALL = "Firewall"
    public static final String COMPUTER_TYPE_HUB = "Hub"
    public static final String COMPUTER_TYPE_NETWORK_PRINTER = "Network printer"
    public static final String COMPUTER_TYPE_DESKTOP_UNIX_COMPUTER = "Unix desktop computer";
    public static final String COMPUTER_TYPE_DESKTOP_WINDOWS_COMPUTER = "Windows desktop computer";
    public static final String COMPUTER_TYPE_DESKTOP = "Desktop computers"
    public static final String COMPUTER_TYPE_MODEM = "Modem";
    public static final String COMPUTER_TYPE_ROUTER = "Router";
    public static final String COMPUTER_TYPE_GATEWAY = "Gateway";
    public static final String COMPUTER_TYPE_NETWORK_CPT_EXT = "Network component extension";
    public static final String COMPUTER_TYPE_ATM_SWITCH = "ATM switch";
    public static final String COMPUTER_TYPE_SWITCH = "Switch";
    public static final String COMPUTER_TYPE_NETWORK_CPT = "Network component";
    public static final String COMPUTER_TYPE_LOAD_BALANCER = "Load Balancer";
    public static final String COMPUTER_TYPE_NET_PRINTER = "Network printer";
    public static final String COMPUTER_TYPE_PDA = "PDA"; // my addition
    public static final String BIZSVC_NETWORK_SYSTEM = "NETWORK";
    public static final String BIZSVC_NETWORK_MODEL = "Network";
    public static final String BIZSVC_NETWORK_TYPE_CPUND = "Connected to the network equipment";
    public static final String BIZSVC_VEM_SERVER = "Virtual Environment Manager Server";
    public static final String VEM_SERVER_BARCODE = "VEMServer-BIZSVC";
    public static final String BIZSVC_CODE = "BIZSVC";
    public static final String BIZ_APP_CODE = "BIZAPP";
    public static final String INFRA_SVC_CODE = "INFRASVC";
    public static final String BIZSVC_NATURE_NAME = "Business service";
    public static final String BIZ_APP_NATURE_NAME = "Business application";
    public static final String INFRA_SVC_NATURE_NAME = "Infrastructure service";


    public static final String HP_VPAR_CONFIG = "hp_vpar_config";
    public static final String HYPER_V_PARTITION_CONFIG = "hyperv_partition_config";
    public static final String IBM_LPAR_PROFILE = "ibm_lpar_profile";
    public static final String Z_OS = "zos";
    public static final String SOLARIS_ZONE_CONFIG = "solaris_zone_config";

    public static final String UNKNOWN_MODEL = "Unknown asset model";
    public static final String UNKNOWN = "Unknown";
    public static final String UNIT_CM = "cm";
    public static final String UNKNOWN_MODEL_NAME = "UNKNOWN_MODEL_NAME";
    public static final String UNKNOWN_SERIAL_NUMBER = "UNKNOWN_SERIAL_NUMBER";

    public static final String TYPE_BUSINESS_APPLICATION = "business_application";
    public static final String TYPE_BUSINESS_SERVICE = "business_service";
    public static final String TYPE_INFRASTRUCTURE_SERVICE = "infrastructure_service";
    public static final String BARCODE_BUSINESS_APPLICATION = "SER000025";
    public static final String BARCODE_BUSINESS_SERVICE = "SER000022";
    public static final String BARCODE_INFRASTRUCTURE_SERVICE = "SER00008";

    public static final String LMS_OPTIONS_INSTALLED_HEADER = "OPTIONS_INSTALLED";
    public static final String LMS_OPTIONS_IN_USE_HEADER = "OPTIONS_IN_USE";
    public static final String LMS_MACHINE_ID_HEADER = "MACHINE_ID";
    public static final String LMS_VIRTUAL_MACHINE_ID_HEADER = "VMACHINE_ID";
    public static final String LMS_DB_NAME_HEADER = "DB_NAME";
    public static final String LMS_OPTIONS_SEPARATOR = " ";
    public static final int LMS_OPTIONS_STATUS_INSTALLED = 0;
    public static final int LMS_OPTIONS_STATUS_IN_USE = 3;
    public static final int LMS_PACKS_STATUS_GRANTED = 0;
    public static final int LMS_PACKS_STATUS_AGREED = 3;

    public static final String EMC_AUTOSTART_CLUSTER = "emc_autostart_cluster";
    public static final String HACMP_CLUSTER = "hacmpcluster";
    public static final String IBM_MQ_CLUSTER = "mqcluster";
    public static final String MS_CLUSTER = "mscluster";
    public static final String SERVICE_GUARD_CLUSTER = "serviceguardcluster";
    public static final String SUN_CLUSTER = "suncluster";
    public static final String VERITAS_CLUSTER = "veritascluster";
    public static final String VMWARE_CLUSTER = "vmware_cluster";
    public static final String APACHE_TOMCAT_CLUSTER = "tomcatcluster";
    public static final String J2EE_CLUSTER = "j2eecluster";
    public static final String MS_NLB_CLUSTER = "ms_nlb_cluster";
    public static final String ORACLE_RAC = "rac";
    public static final String FAILOVER_CLUSTER = "failover_cluster";
    public static final String LOAD_BALANCING_CLUSTER = "loadbalancecluster";
    public static Map<String, String> OPTIONS_FIRST_USAGE_TIME = new HashMap<String, String>();
    public static Map<String, String> OPTIONS_LAST_USAGE_TIME = new HashMap<String, String>();
    public static Map<String, String> OPTIONS_LAST_SAMPLE_TIME = new HashMap<String, String>();

    private static DataAdapterLogger log;
    private static Properties _lmsOptionsProperties;
    private static final Map<String, String> CI_CPU_NUMBER_ATTR = new HashMap<>();

    static {
        CI_CPU_NUMBER_ATTR.put("ibm_lpar_profile", "online_virtual_cpu");
        CI_CPU_NUMBER_ATTR.put("hp_npar_config", "");
        CI_CPU_NUMBER_ATTR.put("hp_vpar_config", "unbound_cpus");
        CI_CPU_NUMBER_ATTR.put("solaris_zone_config", "dedicated_cpu_ncpus");
        CI_CPU_NUMBER_ATTR.put("xen_domain_config", "xen_cpu_count");
        CI_CPU_NUMBER_ATTR.put("kvm_domain_config", "kvm_cpu_count");
        CI_CPU_NUMBER_ATTR.put("vmware_host_resource", "vm_num_cpus");
    }

    public static void setLog(def logger) {
        log = logger;
    }

    public static def getResourceCPUNumber(def virtualHostResource, def defaultCPUNumber) {
        if (virtualHostResource != null) {
            String ciType = String.valueOf(virtualHostResource.getAt("root_class"));
            String attributeName = CI_CPU_NUMBER_ATTR.get(ciType);
            if (!fIsEmpty(attributeName)) {
                def cpuNumber = virtualHostResource.getAt(attributeName);
                if ((cpuNumber instanceof Integer || cpuNumber instanceof Float) && cpuNumber != null && cpuNumber > 0)
                    return cpuNumber;
            }
        }
        return defaultCPUNumber;
    }

    public static boolean isLparVpar(String rootClass) {
        if (!fIsEmpty(rootClass) &&
                (rootClass.equals(HP_VPAR_CONFIG) || rootClass.equals(HYPER_V_PARTITION_CONFIG) ||
                        rootClass.equals(IBM_LPAR_PROFILE) || rootClass.equals(Z_OS))) {
            return true;
        }
        return false;
    }

    public static String fEDDIGetSCLogicalName(def strServerID, def strNMID) {
        return strServerID + "." + strNMID;
    }

    public static String fEDDIGetComputerManufacturer(def strDISystemManufacturer, def strNDHWManufacturer) {
        def retVal = getFirstNotEmpty(strDISystemManufacturer, strNDHWManufacturer);
        if (fIsEmpty(retVal)) {
            retVal = UNKNOWN;
        }
        return retVal;
    }

    public static def concatIfNotEmpty(def ... strings) {
        def retVal = "";
        for (String value : strings) {
            if (!fIsEmpty(value)) {
                if (retVal.size() > 0) {
                    retVal = retVal + " ";
                }
                retVal = retVal + value;

            }
        }
        return retVal;


    }

    public static def fEDDIGetACComputerDescEx(def strManufacturer, def strModel, def strNDFamily) {
        def retVal = "";
        if (!fIsEmpty(strManufacturer)) {
            retVal = strManufacturer;
        }

        if (!fIsEmpty(strNDFamily)) {
            if (!fIsEmpty(retVal)) {
                retVal = retVal + " " + strNDFamily;
            } else {
                retVal = strNDFamily;
            }
        }

        if (!fIsEmpty(strModel)) {
            if (!fIsEmpty(retVal)) {
                retVal = retVal + " " + strModel;
            } else {
                retVal = strModel;
            }
        }
        return retVal
    }

    public static def getNetDeviceComputerType(def node_role, def os_family, def os_description) {
        def retval = getComputerType(false, node_role, os_family, os_description);
        if (retval == COMPUTER_TYPE_COMPUTER) {
            retval = COMPUTER_TYPE_NETWORK_CPT;
        }
        return retval;
    }

    public static def getComputerType(def iIsComputerAVM, def node_role, def os_family, def os_description) {
        def retVal = null;
        if (iIsComputerAVM) {
            retVal = COMPUTER_TYPE_VIRTUAL_MACHINE;
        } else {

            retVal = calculateComputerType(node_role, os_family, os_description);
            if (fIsEmpty(retVal)) {
                retVal = COMPUTER_TYPE_COMPUTER;
            }
        }
        return retVal;
    }

    public static def getFirstIpByType(def ipList, String type) {
        sortIpList(ipList);
        for (ip in ipList) {
            if (ip['ip_address_type'].equals(type)) {
                return ip;
            }
        }
        return null;
    }

    public static String getFirstIpV6Address(def ipList) {
        def ip = getFirstIpByType(ipList, 'IPv6');
        if (ip != null) {
            return ip['ip_address_value'];
        }
        return null;
    }

    public static String getFirstIpV4Address(def ipList) {
        def ip = getFirstIpByType(ipList, 'IPv4');
        if (ip != null) {
            return ip['name'];
        }
        return null;
    }

    public static getIpV4SubnetMask(def ipList) {
        def ip = getFirstIpByType(ipList, 'IPv4');
        if (ip != null) {
            return ip['ip_netmask'];
        }
        return null;
    }

    public static getIpV6SubnetMask(def ipList) {
        def ip = getFirstIpByType(ipList, 'IPv6');
        if (ip != null) {
            return ip['ip_netmask'];
        }
        return null;
    }


    public static boolean isSolarisZone(String rootClass) {
        if (!fIsEmpty(rootClass) && rootClass.equals(SOLARIS_ZONE_CONFIG)) {
            return true;
        }
        return false;
    }


    public static String getPhysicalAddress(String Device_PreferredMACAddress) {
        if (fIsEmpty(Device_PreferredMACAddress)) {
            return "";
        } else {
            Device_PreferredMACAddress = Device_PreferredMACAddress.substring(0, 6) + " " + Device_PreferredMACAddress.substring(6, Device_PreferredMACAddress.length());
            return Device_PreferredMACAddress;
        }
    }


    public static String getIpAddress(String ipAddr) {
        if (fIsEmpty(ipAddr)) {
            return "";
        }
        return ipAddr;
    }

    public static String getPrimaryIpAddress(String primaryIpAddress, String ipAddress) {
        if (!fIsEmpty(primaryIpAddress))
            return primaryIpAddress;
        return ipAddress;
    }

    //'---------------------------------------------------------------------------------
    //' Returns MAC Address based on Device_PreferredMACAddress (strNDMAC),
    //' or hwNetworkData.hwNetworkCards(0).hwNICPhysicalAddress (strDIMAC).
    //'---------------------------------------------------------------------------------
    //' AC SC
    public static fEDDIGetMACAddressEx(String strNDMAC, String strDIMAC) {
        def list = [strNDMAC, strDIMAC];
        return getFirstNotEmpty(list);
    }

    public static String getIpAddress(List ipAddresseList) {
        if (isNull(ipAddresseList) || ipAddresseList.isEmpty())
            return "";
        sortIpList(ipAddresseList);
        return ipAddresseList.get(0);
    }


    public static fEDDIGetDomainNameEx(String strDNSName, String strDomainName) {
        if (!fIsEmpty(strDomainName)) {
            return strDomainName;
        } else if (!fIsEmpty(strDNSName)) {
            int index = strDNSName.indexOf(".");
            if (index != -1) {
                return strDNSName.substring(index + 1, strDNSName.length());
            }
        }
        return null;
    }
    /** replace by new function algorithm
     public static String getVMType(boolean iIsComputerAVM, boolean iIsLPARVPAR, String VirtualDevice_Status,
     String hwOSContainerStatus) {def retVal = null;
     if (iIsComputerAVM) {if (!iIsLPARVPAR) {retVal = VirtualDevice_Status;}else {retVal = hwOSContainerStatus;}}else {retVal = pifIgnoreNodeMapping();}return retVal;}*/


    public static String fEDDIGetACWorkGroup(String strBIOSWrkGrpName, String strDomainName, String strWorkGroupName) {
        def list = [strBIOSWrkGrpName, strDomainName, strWorkGroupName];
        return getFirstNotEmpty(list);
    }


    public static String getFolder(boolean iIsComputerAVM, boolean iIsLPAVPAR, String VirtualDevice_VMPath) {
        if (iIsComputerAVM && !iIsLPAVPAR) {
            return VirtualDevice_VMPath;
        } else {
            return pifIgnoreNodeMapping();
        }
    }

    public static def getSerialNumber(boolean iIsComputerAVM, def VirtualDevice_VMUUID, def hwBiosSerialNumber) {
        def retVal;
        if (iIsComputerAVM) {
            //This is a virtual device, code will be set to match the nature Virtual Machine
            retVal = VirtualDevice_VMUUID;
        } else {
            retVal = hwBiosSerialNumber;
        }

        return retVal;
    }

    private static def pifIgnoreNodeMapping() {
        //In mapping XML the ignore-on-null must be true.s
        return null;
    }


    public static String getBrandName(String hwsmbiosSystemManufacturer, String Company_Name) {
        return fEDDIGetACComputerBrand(hwsmbiosSystemManufacturer, Company_Name);
    }

    public static String fEDDIGetACComputerBrand(String strDISystemManufacturer, String strNDHWManufacturer) {
        def strManufacturer = fEDDIGetComputerManufacturer(strDISystemManufacturer, strNDHWManufacturer);
        return toSmart(fEDDITruncate(strManufacturer, 64));
    }

    public static String fEDDITruncate(String str, int n) {
        if (!isNull(str) && str.length() > n) {
            str = str.substring(0, n - 3);
            str += "...";
        }
        return str;
    }


    public static String getNatureCode(boolean iIsComputerAVM) {
        if (iIsComputerAVM) {
            return "CPUVM";
        } else {
            return "CPU";
        }

    }

    public static String validateAndRetrieveSingleUCaseAsset(List assets) {
        if (isNull(assets) || assets.size() == 0) {
            return null;
        }
        if (assets.size() > 1) {
            throw new MessageOnlyPushMappingException("Only one connected Asset CI is allowed.\r\nRemove the incorrect Connected Asset CIs in order to fix.", FAILED_MAPPING_CI_ERROR_ID);
        }
        return uCase((String) assets.iterator().next());
    }

    public static String getModelParentCode(boolean iIsComputerAVM, def node_role, def os_family, def os_description) {
        if (iIsComputerAVM) {
            return MODEL_VM_AC50;
        } else {
            def computerType = getComputerType(false, node_role, os_family, os_description);
            return getBarCodeFromType(computerType, node_role, os_family, os_description);
        }

    }

    // Returns the Asset Manager barCode, according to information of the CI.
    static def getBarCodeFromType(def computerType, def node_role, def os_family, def name) {
        if (computerType.equals(COMPUTER_TYPE_SERVER) ||
                computerType.equals(COMPUTER_TYPE_SERVER_WINDOWS_COMPUTER) ||
                computerType.equals(COMPUTER_TYPE_SERVER_UNIX_COMPUTER)) {
            return SERVER_CODE;
        } else if (computerType.equals(COMPUTER_TYPE_COMPUTER) ||
                computerType.equals(COMPUTER_TYPE_UNIX_COMPUTER) ||
                computerType.equals(COMPUTER_TYPE_WINDOWS_COMPUTER)) {
            return MODEL_WORKSTATION_AC50;
        } else if (computerType.equals(COMPUTER_TYPE_FIREWALL)) {
            return FIREWALL_CODE;
        } else if (computerType.equals(COMPUTER_TYPE_NETWORK_PRINTER)) {
            return NET_PRINTER_CODE;
        } else if (computerType.equals(COMPUTER_TYPE_ATM_SWITCH)) {
            return ATM_SWITCH_CODE;
        } else if (computerType.equals(COMPUTER_TYPE_ROUTER)) {
            return ROUTER_CODE;
        } else if (computerType.equals(COMPUTER_TYPE_SWITCH)) {
            return SWITCH_CODE;
        } else if (computerType.equals(COMPUTER_TYPE_HUB)) {
            return HUB_CODE;
        } else if (computerType.equals(COMPUTER_TYPE_GATEWAY)) {
            return GATEWAY_CODE;
        } else if (computerType.equals(COMPUTER_TYPE_NETWORK_CPT)) {
            return NET_DEVICE_CODE;
        } else if (computerType.equals(COMPUTER_TYPE_MODEM)) {
            return MODEM_CODE;
        } else if (computerType.equals(COMPUTER_TYPE_LOAD_BALANCER)) {
            return LOAD_BALANCER_CODE;
        } else if (computerType.equals(COMPUTER_TYPE_PDA)) {
            return PDA_CODE;
        }
        return MODEL_WORKSTATION_AC50;
    }


    public static String getParentName(String Company_Name) {
        if (fIsEmpty(Company_Name)) {
            return UNKNOWN;
        } else {
            return fEDDITruncate(Company_Name, 80);
        }
    }

    public static String getParentBarCodeFromType(String ciType) {
        if (ciType.equals(TYPE_BUSINESS_APPLICATION)) {
            return BARCODE_BUSINESS_APPLICATION;
        }
        if (ciType.equals(TYPE_BUSINESS_SERVICE)) {
            return BARCODE_BUSINESS_SERVICE;
        }
        if (ciType.equals(TYPE_INFRASTRUCTURE_SERVICE)) {
            return BARCODE_INFRASTRUCTURE_SERVICE;
        }
        return null;
    }

    public static String getNatureCodeFromType(String ciType) {
        if (ciType.equals(TYPE_BUSINESS_APPLICATION)) {
            return BIZ_APP_CODE;
        }
        if (ciType.equals(TYPE_BUSINESS_SERVICE)) {
            return BIZSVC_CODE;
        }
        if (ciType.equals(TYPE_INFRASTRUCTURE_SERVICE)) {
            return INFRA_SVC_CODE;
        }
        return null;
    }

    public static String getNatureNameFromType(String ciType) {
        if (ciType.equals(TYPE_BUSINESS_APPLICATION)) {
            return BIZ_APP_NATURE_NAME;
        }
        if (ciType.equals(TYPE_BUSINESS_SERVICE)) {
            return BIZSVC_NATURE_NAME;
        }
        if (ciType.equals(TYPE_INFRASTRUCTURE_SERVICE)) {
            return INFRA_SVC_NATURE_NAME;
        }
        return null;
    }

    public static def getCoreCount(List cpuCoreList) {
        if (isNull(cpuCoreList) || cpuCoreList.size() == 0) {
            return null;
        }
        int coreCounter = 0;
        for (def cpuCore : cpuCoreList) {
            if (!isNull(cpuCore)) {
                coreCounter += cpuCore;
            }
        }
        return coreCounter;
    }

    //The serial number of the monitor may not be unique. Create a unique name in concatenating the computer
    //AssetTag. Check in addition if there are several computers having the same serial number for that computer
    //and, if so, concatenate an index in addition.

    public static boolean shouldMapMonitor(String hwMonitorSerialNumber) {
        if (!fIsEmpty(hwMonitorSerialNumber)) {
            return true;
        }
        return false;
    }

    public static String getMonitorModelName(def vendor, def name) {
        String strModelName = name;

        if (!fIsEmpty(vendor) && ((name.length() <= vendor.length()) || (name.substring(0, vendor.length()) != vendor))) {
            strModelName = vendor + " " + name;
        }
        if (strModelName == "") {
            strModelName = UNKNOWN;
        }
        return strModelName;
    }

    public static String getAssetTagCRSystem(String strAssetTag, boolean isSolarisZone) {
        if (isSolarisZone) {
            strAssetTag = strAssetTag + "SolarisZoneBiz";
        } else {
            strAssetTag = strAssetTag + "VMwareESXBiz";
        }
        return strAssetTag;
    }

    public static int getLogicalCpuCount(List cpuList) {
        if (cpuList.size() == 0) {
            return 0;
        }
        int counter = 0;
        for (def cpu : cpuList) {
            counter += cpu['logical_cpu_number'];
        }
        return counter;
    }

    public static def getResfreshRate(int i, int hwDisplayGraphicsAdaptersNum, int hwDisplayDesktopRefreshRate) {
        if (i > hwDisplayGraphicsAdaptersNum) {
            return pifIgnoreNodeMapping();
        }
        return hwDisplayDesktopRefreshRate;
    }

    public static def getHorizontRes(int i, int hwDisplayGraphicsAdaptersNum, def hwDisplayDesktopResolutionX) {
        if (i > hwDisplayGraphicsAdaptersNum) {
            return pifIgnoreNodeMapping();
        } else {
            return hwDisplayDesktopResolutionX;
        }
    }

    public static boolean isExtensionCardValid(String hwCardName, String hwCardClass, String hwCardVendor) {
        if (fIsEmpty(hwCardName)) {
            return false;
        }
        if (fIsEmpty(hwCardName) && fIsEmpty(hwCardClass) && fIsEmpty(hwCardVendor)) { // WHY??
            return false;
        }
        return true;
    }

    public static String getCardID(String cardId, int i, List cardsIdList) {
        if (fIsEmpty(cardId) || isNull(cardsIdList)) {
            return i;
        }
        int index = 0;
        for (int n = 0; n < i; n++) {
            def currCardId = cardsIdList.get(n);
            if (!isNull(currCardId) && cardId.equals(currCardId)) {
                index++;
            }
        }
        if (index > 0) {
            cardId = cardId + "_" + index;
        }
        return cardId;
    }

    public static String getCardName(String hwCardName) {
        def strName;
        if (fIsEmpty(hwCardName)) {
            strName = "N / A";
        } else {
            strName = toSmart(hwCardName);
        }
        return strName;
    }

    public static def getCardType(def hwCardClass) {
        if (!fIsEmpty(hwCardClass)) {
            return hwCardClass;
        }
        return "N / A";
    }

    public static String getCardVendorName(String hwCardVendor) {
        String retVal;
        if (!fIsEmpty(hwCardVendor)) {
            retVal = toSmart(hwCardVendor);
        } else {
            retVal = "N / A";
        }
        return fEDDITruncate(retVal, 30);
    }

    public static def getFSMountPoint(String hwMountPointMountedTo, String hwMountPointVolumeType) {
        def retVal;
        if (fIsEmpty(hwMountPointMountedTo)) {
            retVal = leftPart(hwMountPointVolumeType, ":") + ":";
        } else {
            retVal = hwMountPointMountedTo;
        }
        return retVal;
    }

    public static boolean isDHCPEnabled() {
    }


    public static getInterfaceDescription(String strVal, String strDefault) {
        if (!fIsEmpty(strVal)) {
            return strVal;
        } else {
            return strDefault;
        }
    }

    public static def getPhysAddress(String hwNICPhysicalAddress, String hwLocalMachineID, String hwNetworkCards_Seq) {
        def retVal;
        if (!fIsEmpty(hwNICPhysicalAddress)) {
            retVal = hwNICPhysicalAddress
        } else if (!fIsEmpty(hwLocalMachineID)) {
            retVal = hwLocalMachineID + " - " + hwNetworkCards_Seq;
        } else {
            retVal = "N / A" + " - " + hwNetworkCards_Seq;
        }
        return retVal;
    }

    public static String getDNSSuffix(List ipList) {
        if (isNull(ipList)) {
            return null;
        }
        sortIpList(ipList);
        for (ip in ipList) {
            String authoritativeDnsName = ip['authoritative_dns_name'];
            String routingDomain = ip['routing_domain'];
            if (!fIsEmpty(authoritativeDnsName)) {
                return rightPart(authoritativeDnsName, ".");
            } else if (!fIsEmpty(routingDomain)) {
                return routingDomain;
            }
        }
        return null;
    }

    public static def getVerticalRes(int i, int hwDisplayGraphicsAdaptersNum, hwDisplayDesktopResolutionY) {
        if (i > hwDisplayGraphicsAdaptersNum) {
            return pifIgnoreNodeMapping();
        } else {
            return hwDisplayDesktopResolutionY;
        }
    }

    public static String getNormalizedModelName(String name, String version) {
        def retVal = "";
        if (!fIsEmpty(name)) {
            name.replaceAll("\'", "\"");
            retVal = name;
        }
        if (!fIsEmpty(version)) {
            def normVersion = version;
            int dotIndex = version.indexOf(".");
            if (dotIndex > -1) {
                normVersion = version.substring(0, dotIndex);
            }
            //int spaceIndex = normVersion.indexOf(" ");
            //if(spaceIndex > -1){
            //    String tempNormVersion = normVersion.substring(0,spaceIndex);
            //    if(tempNormVersion.isNumber()){
            //        normVersion = tempNormVersion;
            //    }
            //}
            if (!normVersion.equals("xx")) {
                retVal += " " + normVersion;
            }
        }
        return retVal;
    }

    public static String getNormalizedCPU(String cpu) {
        String retVal = cpu;

        //Add the new CPUTypes to be matched.
        //The first element of the array is the regexp
        //The second one is the replacement string using capture groups.
        //if nothing is matched, then the string is returned without any change

        def CPUregexp = [
                //Intel Xeon CPU
                //?i <- case insensitive
                //[ /(?i)\bIntel.*? \bXeon.*? (\b[a-z0-9]+-?[0-9]+\b).*/ , "Intel Xeon \$1" ],
                [/(?i)\bIntel.*? \bXeon.*? \bCPU\b(.*?\w*-*\d{4}).*/, "Intel Xeon \$1"],
                //Match everything
                //[ /(.*)/ , "\$1" ],

        ];

        for (regexp in CPUregexp) {
            if (cpu =~ regexp[0]) {
                retVal = cpu.replaceAll(regexp[0], regexp[1]);
                //retVal = retVal.replace("CPU","");
                break;
            }
        }

        return retVal;
    }

    public static String getUserName(String domainAndUser) {
        if (!isNull(domainAndUser) && domainAndUser.contains("\\")) {
            return domainAndUser.substring(domainAndUser.indexOf("\\") + 1, domainAndUser.length());
        }
        return domainAndUser;
    }

    public static String getDomainName(String domainAndUser) {
        if (!isNull(domainAndUser) && domainAndUser.contains("\\")) {
            return domainAndUser.substring(0, domainAndUser.indexOf("\\"));
        }
        return null;
    }

    public static String getModelName(def ... listValues) {
        def retVal = getFirstNotEmpty(listValues);
        if (fIsEmpty(retVal)) {
            retVal = UNKNOWN_MODEL_NAME;
        }
        return retVal;
    }

    public static String getEnd1ExternalId(ExternalRelationId externalRelationId) {
        validateExternalId(externalRelationId)
        ExternalCiId ciId = externalRelationId.getEnd1Id();
        return getAMPrimaryID(ciId);
    }

    public static String getEnd2ExternalId(ExternalRelationId externalRelationId) {
        validateExternalId(externalRelationId)
        ExternalCiId ciId = externalRelationId.getEnd2Id();
        return getAMPrimaryID(ciId);
    }

    public static String getExternalId(ExternalCiId externalCiId) {
        validateExternalId(externalCiId);
        return getAMPrimaryID(externalCiId);
    }

    public static String getAMPrimaryID(ExternalCiId ciId) {
        def retVal = ciId.getPropertyValue(PushDirector.AM_PRIMARY_ID);
        if (isNull(retVal)) {
            throw new MessageOnlyPushMappingException('\r\n A CI [' + nicelyPrintExternalId(ciId) + '] was not found in AM and probably was not pushed yet as a Root.' +
                    '\r\n May occur in a few scenarios, for example:' +
                    '\r\n 1) A different TQL that pushes this CI as Root is not scheduled/ordered to run before this TQL.' +
                    '\r\n 2) A CI was added to the UCMDB during the Data Push Job Exeution - Will be fixed on next execution.\r\n', FAILED_MAPPING_CI_ERROR_ID);
        }
        return retVal;
    }

    public static String getSafeAMPrimaryID(ExternalCiId ciId) {
        if (isNull(ciId)) {
            return "0";
        }
        def retVal = ciId.getPropertyValue(PushDirector.AM_PRIMARY_ID);
        if (isNull(retVal)) {
            return "0";
        }
        return retVal;
    }

    public static String nicelyPrintExternalId(ExternalId id) {
        if (id.isCmdbId()) {
            Object value = id.getPropertyValue(ExternalId.INTERNAL_ID_PROPERTY_NAME);
            if (value != null) {
                return id.getClassName() + "::" + String.valueOf(value);
            } else {
                return String.valueOf(id);
            }
        } else {
            return String.valueOf(id);
        }
    }

    private static def validateExternalId(ExternalId externalId) {
        if (externalId == null) {
            throw new MessageOnlyPushMappingException('External id is empty. Make Sure OutputCI is root', FAILED_MAPPING_CI_ERROR_ID);
        }
    }

    public static void sortIpList(List ipList) {
    }


    private static String calculateComputerType(def node_role, String os_family, String os_description) {
        if (!fIsEmpty(node_role)) {

            if (node_role.contains("firewall")) {
                return COMPUTER_TYPE_FIREWALL;
            } else if (node_role.contains("printer")) {
                return COMPUTER_TYPE_NETWORK_PRINTER;
            } else if (node_role.contains("atm_switch")) {
                return COMPUTER_TYPE_ATM_SWITCH;
            } else if (node_role.contains("router")) {
                return COMPUTER_TYPE_ROUTER;
            } else if (node_role.contains("lan_switch")) {
                return COMPUTER_TYPE_SWITCH;
            } else if (node_role.contains("ethernet")) {
                return COMPUTER_TYPE_HUB;
            } else if (node_role.contains("hub")) {
                return COMPUTER_TYPE_HUB;
            } else if (node_role.contains("token_ring")) {
                return COMPUTER_TYPE_NETWORK_CPT;
            } else if (node_role.contains("wireless_access_point")) {
                return COMPUTER_TYPE_GATEWAY;
            } else if (node_role.contains("vpn_gateway")) {
                return COMPUTER_TYPE_GATEWAY;
            } else if (node_role.contains("appletalk_gateway")) {
                return COMPUTER_TYPE_GATEWAY;
            } else if (node_role.contains("voice_gateway")) {
                return COMPUTER_TYPE_GATEWAY;
            } else if (node_role.contains("traffic_redictor")) {
                return COMPUTER_TYPE_NETWORK_CPT;
            } else if (node_role.contains("bandwidth_manager")) {
                return COMPUTER_TYPE_NETWORK_CPT;
            } else if (node_role.contains("kvm_switch")) {
                return COMPUTER_TYPE_NETWORK_CPT;
            } else if (node_role.contains("csu_dsu")) {
                return COMPUTER_TYPE_NETWORK_CPT;
            } else if (node_role.contains("cable_modem")) {
                return COMPUTER_TYPE_MODEM;
            } else if (node_role.contains("nat_router")) {
                return COMPUTER_TYPE_ROUTER;
            } else if (node_role.contains("san_gateway")) {
                return COMPUTER_TYPE_GATEWAY;
            } else if (node_role.contains("adsl_modem")) {
                return COMPUTER_TYPE_MODEM;
            } else if (node_role.contains("frame_relay_switch")) {
                return COMPUTER_TYPE_SWITCH;
            } else if (node_role.contains("multicast_enabled_router")) {
                return COMPUTER_TYPE_ROUTER;
            } else if (node_role.contains("load_balancer")) {
                return COMPUTER_TYPE_LOAD_BALANCER;
            } else if (node_role.contains("san_switch")) {
                return COMPUTER_TYPE_SWITCH;
            } else if (node_role.contains("san_router")) {
                return COMPUTER_TYPE_ROUTER;
            } else if (node_role.contains("adsl_modem")) {
                return COMPUTER_TYPE_MODEM;
            } else if (node_role.contains("fddi")) {
                return COMPUTER_TYPE_NETWORK_CPT;
            } else if (node_role.contains("pda_handheld")) {
                return COMPUTER_TYPE_PDA;
            } else if (node_role.contains("voice_switch")) {
                return COMPUTER_TYPE_SWITCH;
            } else if (node_role.contains("undefined_network_component")) {
                return COMPUTER_TYPE_NETWORK_CPT;
            } else if (node_role.contains("server")) {
                def retVal;
                if (!fIsEmpty(os_family)) {
                    if (containsIgnoreCase(os_family, "windows")) {
                        retVal = COMPUTER_TYPE_SERVER_WINDOWS_COMPUTER;
                    } else if (containsIgnoreCase(os_family, "unix")) {
                        retVal = COMPUTER_TYPE_SERVER_UNIX_COMPUTER;
                    }
                } else if (fIsEmpty(retVal) && !fIsEmpty(os_description)) {
                    if (containsIgnoreCase(os_description, "windows")) {
                        retVal = COMPUTER_TYPE_SERVER_WINDOWS_COMPUTER;
                    } else if (containsIgnoreCase(os_description, "unix")) {
                        retVal = COMPUTER_TYPE_SERVER_UNIX_COMPUTER;
                    }
                }
                if (fIsEmpty(retVal)) {
                    retVal = COMPUTER_TYPE_SERVER;
                    ;
                }
                return retVal;
            } else if (node_role.contains("desktop")) {
                def retVal;
                if (!fIsEmpty(os_family)) {
                    if (containsIgnoreCase(os_family, "windows")) {
                        retVal = COMPUTER_TYPE_DESKTOP_WINDOWS_COMPUTER;
                    } else if (containsIgnoreCase(os_family, "unix")) {
                        retVal = COMPUTER_TYPE_DESKTOP_UNIX_COMPUTER;
                    }
                } else if (!fIsEmpty(os_description)) {
                    if (containsIgnoreCase(os_description, "windows")) {
                        retVal = COMPUTER_TYPE_DESKTOP_WINDOWS_COMPUTER;
                    } else if (containsIgnoreCase(os_description, "unix")) {
                        retVal = COMPUTER_TYPE_DESKTOP_UNIX_COMPUTER;
                    }
                }
                if (fIsEmpty(retVal)) {
                    retVal = COMPUTER_TYPE_DESKTOP;
                }
                return retVal;
            }

        } else {
            def retVal;
            if (!fIsEmpty(os_family)) {
                if (containsIgnoreCase(os_family, "windows")) {
                    retVal = COMPUTER_TYPE_WINDOWS_COMPUTER;
                } else if (containsIgnoreCase(os_family, "unix")) {
                    retVal = COMPUTER_TYPE_UNIX_COMPUTER;
                }
            }
            if (!fIsEmpty(os_description)) {
                if (containsIgnoreCase(os_description, "windows")) {
                    retVal = COMPUTER_TYPE_WINDOWS_COMPUTER;
                } else if (containsIgnoreCase(os_description, "unix")) {
                    retVal = COMPUTER_TYPE_UNIX_COMPUTER;
                }
            }
            if (fIsEmpty(retVal)) {
                retVal = COMPUTER_TYPE_COMPUTER;
            }
            return retVal;
        }
    }

    public static String getSoftwareBarCode(def dynamicMapHolder, def versionId, def categoryId) {
        def retVal;
        if (!fIsEmpty(versionId)) {
            def barCodeByVersionIdMap = dynamicMapHolder.getMap("BarCodeByVersionId");
            if (!isNull(barCodeByVersionIdMap)) {
                retVal = barCodeByVersionIdMap.get("PDI|" + versionId);
            }
        }
        if ((fIsEmpty(retVal) || retVal.equals(MODEL_SOFTWARE_INSTAL_AC50)) && !fIsEmpty(categoryId)) {
            def barCodeByCategoryMap = dynamicMapHolder.getMap("BarCodeByCategoryId");
            if (!isNull(barCodeByCategoryMap)) {
                retVal = barCodeByCategoryMap.get(String.valueOf(categoryId));
            }
        }

        if (fIsEmpty(retVal)) {
            retVal = MODEL_SOFTWARE_INSTAL_AC50;
        }
        if (!isNull(log) && log.isDebugEnabled()) {
            log.debug("getSoftwareBarCode. return value: " + retVal);
        }
        return retVal;
    }

    public static boolean getIsInventModelExist(def dynamicMapHolder, def inventKey) {
        def isResolvedMap = dynamicMapHolder.getMap("ResolvedByInventKey");
        if (isNull(isResolvedMap)) {
            return false;
        }
        def isResolved = isResolvedMap.get(inventKey);
        if (isNull(isResolved)) {
            return false;
        }
        return true;
    }

    public static boolean getIsInventModelResolved(def dynamicMapHolder, def versionId) {
        def isResolvedMap = dynamicMapHolder.getMap("ResolvedByInventKey");
        if (isNull(isResolvedMap)) {
            return false;
        }
        def retVal = isResolvedMap.get("PDI|" + versionId);
        if (isNull(retVal) || retVal.equals("0")) {
            return false;
        }
        return retVal;
    }

    public static String getFinalModelId(def dynamicMapHolder, def inventoryKey, boolean isInventModelExist) {
        if (!isInventModelExist) {
            return null;
        }
        def finalIdMap = dynamicMapHolder.getMap("FinalIdByInventKey");
        def retVal = finalIdMap.get(inventoryKey);
        if (fIsEmpty(retVal) || retVal.equals("0")) {
            return null;
        } else {
            return retVal;
        }
    }


    public static boolean hasFinalModelId(def dynamicMapHolder, def versionId) {
        def finalIdMap = dynamicMapHolder.getMap("FinalIdByInventKey");
        if (isNull(finalIdMap)) {
            return false;
        }
        def retVal = finalIdMap.get("PDI|" + versionId);
        if (fIsEmpty(retVal) || retVal.equals("0")) {
            return false;
        }
        return true;
    }

    public static String getModelIdByBarCode(def dynamicMapHolder, String barCode) {
        def modelIdBarCodeMap = dynamicMapHolder.getMap("ModelIdByBarCode");
        if (isNull(modelIdBarCodeMap) || isNull(modelIdBarCodeMap.get(barCode))) {
            throw new MessageOnlyPushMappingException("Asset Manager has no model with bar code [" + barCode + "].", FAILED_MAPPING_CI_ERROR_ID);
        }
        return modelIdBarCodeMap.get(barCode);
    }

    public static String getAMPrimaryID(String externalId) {
        if (!isNull(log) && log.isDebugEnabled()) {
            log.debug("getAMPrimaryID: " + externalId);
        }
        if (fIsEmpty(externalId) || !externalId.contains("AM_PRIMARY_ID%3DINTEGER%3D")) {
            throw new MessageOnlyPushMappingException('Groovy Function: getAMPrimaryID. \r\n A CI [' + String.valueOf(externalId) + '] was not found in AM and probably was not pushed yet as a Root.' +
                    '\r\n May occur in a few scenarios, for example:' +
                    '\r\n 1) A different TQL that pushes this CI as Root is not scheduled/ordered to run before this TQL.' +
                    '\r\n 2) A CI was added to the UCMDB during the Data Push Job Exeution - Will be fixed on next execution.\r\n', FAILED_MAPPING_CI_ERROR_ID);
        }
        int beginIndex = externalId.indexOf("AM_PRIMARY_ID%3DINTEGER%3D") + 26;
        int endIndex = externalId.indexOf("%", beginIndex + 1);
        if (endIndex < 0) {
            throw new MessageOnlyPushMappingException("Groovy Function: getAMPrimaryID. Extrernal ID: [" + externalId + "] is not valid", FAILED_MAPPING_CI_ERROR_ID);
        }
        return externalId.substring(beginIndex, endIndex);

    }

    public static String getValueFromCsv(byte[] csvAsBytes, String headerName) {
        ByteArrayInputStream bais = new ByteArrayInputStream(csvAsBytes);
        GZIPInputStream gzis = new GZIPInputStream(bais);
        InputStreamReader reader = new InputStreamReader(gzis);

        CsvReader csvReader = new CsvReader(reader);
        String result = csvReader.get(headerName);
        csvReader.close();
        return result;
    }

    public static String getValueFromStringCsv(String csvStr, String headerName) {
        StringReader stringReader = new StringReader(csvStr);
        CsvReader csvReader = new CsvReader(stringReader);
        csvReader.readHeaders();
        csvReader.readRecord();
        String result = csvReader.get(headerName);
        csvReader.close();
        return result;
    }

    public static String getCsvFile(byte[] csvAsBytes, String fileName) {
        ByteArrayInputStream bais = new ByteArrayInputStream(csvAsBytes);
        GZIPInputStream gzis = new GZIPInputStream(bais);
        InputStreamReader reader = new InputStreamReader(gzis);
        StringBuffer retVal = new StringBuffer();
        String line = "";
        boolean isReadingRelevantFile = false;
        while ((line = reader.readLine()) != null) {
            if (line.equals('') && isReadingRelevantFile) {
                break;
            } else if (line.equals(fileName)) {
                isReadingRelevantFile = true;
                continue;
            }
            if (isReadingRelevantFile) {
                retVal.append(line).append('\n');
            }
        }
        reader.close();
        return retVal.toString();
    }


    public static String convertCsvBytesToString(byte[] csvAsBytes) {
        ByteArrayInputStream bais = new ByteArrayInputStream(csvAsBytes);
        GZIPInputStream gzis = new GZIPInputStream(bais);
        InputStreamReader reader = new InputStreamReader(gzis);
        String retVal = "";
        String line = "";
        while ((line = reader.readLine()) != null) {
            retVal += line + '\n';
        }
        return retVal;
    }

    public static Date interpretDate(String strDate) {
        if (strDate != null && !strDate.trim().equals("")) {
            SimpleDateFormat ft = new SimpleDateFormat(LMS_DATE_FORMAT);
            Date d = ft.parse(strDate);
            return d;
        }
        return null;

    }

    public static void cleanOptionsUsageInfo() {
        OPTIONS_FIRST_USAGE_TIME.clear();
        OPTIONS_LAST_USAGE_TIME.clear();
        OPTIONS_LAST_SAMPLE_TIME.clear();

    }

    public
    static void putOptionsUsageTime(String optionName, String vfirstUsageTime, String vlastUsageTime, String vlastSampleTime) {

        Date first_usage_time = OPTIONS_FIRST_USAGE_TIME.get(optionName);
        Date firstUsageTime = interpretDate(vfirstUsageTime);
        if (first_usage_time == null)
            OPTIONS_FIRST_USAGE_TIME.put(optionName, firstUsageTime);
        else if (firstUsageTime != null && first_usage_time > firstUsageTime)
            OPTIONS_FIRST_USAGE_TIME.putAt(optionName, firstUsageTime);

        Date last_usage_time = OPTIONS_LAST_USAGE_TIME.get(optionName);
        Date lastUsageTime = interpretDate(vlastUsageTime);
        if (last_usage_time == null)
            OPTIONS_LAST_USAGE_TIME.put(optionName, lastUsageTime);
        else if (lastUsageTime != null && last_usage_time < lastUsageTime)
            OPTIONS_LAST_USAGE_TIME.putAt(optionName, lastUsageTime);

        Date last_sample_time = OPTIONS_LAST_SAMPLE_TIME.get(optionName);
        Date lastSampleTime = interpretDate(vlastSampleTime);
        if (last_sample_time == null)
            OPTIONS_LAST_SAMPLE_TIME.put(optionName, lastSampleTime);
        else
            OPTIONS_LAST_SAMPLE_TIME.putAt(optionName, lastSampleTime);
    }

    public static Date getOptionsFirstUsageTime(String optionName) {
        return OPTIONS_FIRST_USAGE_TIME.get(optionName);
    }

    public static Date getOptionsLastUsageTime(String optionName) {
        return OPTIONS_LAST_USAGE_TIME.get(optionName);
    }

    public static Date getOptionsLastSampleTime(String optionName) {
        return OPTIONS_LAST_SAMPLE_TIME.get(optionName);
    }

    private static List<String> getOracleComponentList(String vLMS_OPTIONS, String optionType) {
        List<String> optionsList = new ArrayList<String>();

        StringReader stringReader = new StringReader(vLMS_OPTIONS);
        CsvReader csvReader = new CsvReader(stringReader);
        csvReader.readHeaders();
        while (csvReader.readRecord()) {
            String optionView = csvReader.get("OPTION_NAME");

            // Check installed options
            if (optionType.equalsIgnoreCase("OPTIONS_INSTALLED")) {
                String installedStatus = csvReader.get("COL020");
                if (optionView.equalsIgnoreCase('V$OPTION') && installedStatus.equalsIgnoreCase("TRUE")) {
                    String optionName = csvReader.get("COL010");
                    if (optionName.equalsIgnoreCase("Advanced Compression"))
                        optionsList.add("AC");
                    else if (optionName.equalsIgnoreCase("Active Data Guard"))
                        optionsList.add("ADG");
                    else if (optionName.equalsIgnoreCase("Transparent Data Encryption") || optionName.equalsIgnoreCase("Backup Encryption"))
                        optionsList.add("AS");
                    else if (optionName.equalsIgnoreCase("Data Mining"))
                        optionsList.add("AA");
                    else if (optionName.equalsIgnoreCase("Oracle Database Vault"))
                        optionsList.add("DV");
                    else if (optionName.equalsIgnoreCase("Oracle Label Security"))
                        optionsList.add("LS");
                    else if (optionName.equalsIgnoreCase("OLAP"))
                        optionsList.add("OL");
                    else if (optionName.equalsIgnoreCase("Partitioning"))
                        optionsList.add("P");
                    else if (optionName.equalsIgnoreCase("Real Application Clusters"))
                        optionsList.add("RAC");
                    else if (optionName.equalsIgnoreCase("Real Application Testing"))
                        optionsList.add("RAT");
                    else if (optionName.equalsIgnoreCase("Spatial"))
                        optionsList.add("SP");
                }
            }

            if (optionType.equalsIgnoreCase("OPTIONS_IN_USE") || optionType.equalsIgnoreCase("OPTIONS_INSTALLED")) {
                String usageStatus = csvReader.get("COL050");
                if (optionView.equalsIgnoreCase("DBA_FEATURE_USAGE_STATISTICS")) {

                    String firstUsageTime = csvReader.get("COL060");
                    String lastUsageTime = csvReader.get("COL070");
                    String lastSampleTime = csvReader.get("COL080");

                    if ((optionType.equalsIgnoreCase("OPTIONS_IN_USE") && usageStatus.equalsIgnoreCase("TRUE"))
                            || (optionType.equalsIgnoreCase("OPTIONS_INSTALLED") && !firstUsageTime.trim().equals(""))) {
                        String optionName = csvReader.get("COL010");
                        int optionCount = optionsList.size();

                        if (optionName.equalsIgnoreCase("Active Data Guard - Real-Time Query on Physical Standby") ||
                                optionName.equalsIgnoreCase("Global Data Services")) {
                            optionsList.add("ADG");
                        }

                        if (optionName.equalsIgnoreCase("Data Mining"))
                            optionsList.add("AA");

                        if (optionName.equalsIgnoreCase("Backup HIGH Compression") ||
                                optionName.equalsIgnoreCase("Backup LOW Compression") ||
                                optionName.equalsIgnoreCase("Backup MEDIUM Compression") ||
                                optionName.equalsIgnoreCase("Backup ZLIB Compression") ||
                                optionName.equalsIgnoreCase("HeapCompression") ||
                                optionName.equalsIgnoreCase("SecureFile Compression (user)") ||
                                optionName.equalsIgnoreCase("SecureFile Deduplication (user)"))
                            optionsList.add("AC");

                        if (optionName.equalsIgnoreCase("Backup Encryption") ||
                                optionName.equalsIgnoreCase("Encrypted Tablespaces") ||
                                optionName.equalsIgnoreCase("SecureFile Encryption (user)") ||
                                optionName.equalsIgnoreCase("Transparent Data Encryption"))
                            optionsList.add("AS");

                        if (optionName.equalsIgnoreCase("Oracle Database Vault"))
                            optionsList.add("DV");

                        if (optionName.equalsIgnoreCase("Exadata"))
                            optionsList.add("ED");

                        if (optionName.equalsIgnoreCase("Label Security"))
                            optionsList.add("LS");

                        if (optionName.equalsIgnoreCase("OLAP - Analytic Workspaces") ||
                                optionName.equalsIgnoreCase("OLAP - Cubes"))
                            optionsList.add("OL");

                        if (optionName.equalsIgnoreCase("Partitioning (user)") ||
                                optionName.equalsIgnoreCase("Zone maps"))
                            optionsList.add("P");

                        if (optionName.equalsIgnoreCase("Real Application Clusters (RAC)"))
                            optionsList.add("RAC");

                        if (optionName.equalsIgnoreCase("Database Replay: Workload Capture") ||
                                optionName.equalsIgnoreCase("Database Replay: Workload Replay") ||
                                optionName.equalsIgnoreCase("SQL Performance Analyzer"))
                            optionsList.add("RAT");

                        if (optionName.equalsIgnoreCase("Spatial"))
                            optionsList.add("SP");

                        if (optionsList.size() > optionCount) {
                            String option = optionsList.last();
                            if (!firstUsageTime.trim().equals(""))
                                putOptionsUsageTime(option, firstUsageTime, lastUsageTime, lastSampleTime);
                        }

                    }
                }
            }

            if (optionType.equalsIgnoreCase("PACKS_GRANTED") || optionType.equalsIgnoreCase("PACKS_AGREED")) {
                // installed packs

                String usageStatus = csvReader.get("COL050");
                if (optionView.equalsIgnoreCase("DBA_FEATURE_USAGE_STATISTICS")) {

                    String firstUsageTime = csvReader.get("COL060");
                    String lastUsageTime = csvReader.get("COL070");
                    String lastSampleTime = csvReader.get("COL080");

                    if ((optionType.equalsIgnoreCase("PACKS_AGREED") && usageStatus.equalsIgnoreCase("TRUE"))
                            || (optionType.equalsIgnoreCase("PACKS_GRANTED") && !firstUsageTime.trim().equals(""))) {
                        String optionName = csvReader.get("COL010");
                        int optionCount = optionsList.size();
                        if (optionName.equalsIgnoreCase("Change Management Pack"))
                            optionsList.add("DCM");

                        if (optionName.equalsIgnoreCase("EM Config Management Pack"))
                            optionsList.add("DCO");

                        if (optionName.equalsIgnoreCase("Data Masking Pack"))
                            optionsList.add("DDM");

                        if (optionName.equalsIgnoreCase("ADDM") ||
                                optionName.equalsIgnoreCase("AWR Baseline") ||
                                optionName.equalsIgnoreCase("AWR Baseline Template") ||
                                optionName.equalsIgnoreCase("AWR Report") ||
                                optionName.equalsIgnoreCase("Automatic Workload Repository") ||
                                optionName.equalsIgnoreCase("Baseline Adaptive Thresholds") ||
                                optionName.equalsIgnoreCase("Baseline Static Computations") ||
                                optionName.equalsIgnoreCase("Diagnostic Pack") ||
                                optionName.equalsIgnoreCase("EM Performance Page"))
                            optionsList.add("DD");

                        if (optionName.equalsIgnoreCase("EM Standalone Provisioning and Patch Automation Pack"))
                            optionsList.add("OPP");

                        if (optionName.equalsIgnoreCase("EM Database Provisioning and Patch Automation Pack"))
                            optionsList.add("DPP");

                        if (optionName.equalsIgnoreCase("Automatic Maintenance - SQL Tuning Advisor") ||
                                optionName.equalsIgnoreCase("Automatic SQL Tuning Advisor") ||
                                optionName.equalsIgnoreCase("Real-Time SQL Monitoring") ||
                                optionName.equalsIgnoreCase("SQL Access Advisor") ||
                                optionName.equalsIgnoreCase("SQL Monitoring and Tuning pages") ||
                                optionName.equalsIgnoreCase("SQL Profile") ||
                                optionName.equalsIgnoreCase("SQL Tuning Advisor") ||
                                optionName.equalsIgnoreCase("SQL Tuning Set (user)") ||
                                optionName.equalsIgnoreCase("Tuning Pack"))
                            optionsList.add("DT");

                        if (optionsList.size() > optionCount) {
                            String option = optionsList.last();
                            if (!firstUsageTime.trim().equals(""))
                                putOptionsUsageTime(option, firstUsageTime, lastUsageTime, lastSampleTime);
                        }
                    }
                }
            }
        }
        csvReader.close();
        return optionsList.unique();
    }

    // caculate Oracle Model's Edition field by DB_EDITION and SOCKETS_POPULATED_PHYS in csv
    public static String getDdEdition(String vSocketNumber, String vDbEdition) {
        if (fIsEmpty(vDbEdition)) {
            int num_socket = (fIsEmpty(vSocketNumber) || fIsEmpty(vSocketNumber.trim())) ? 0 : Integer.parseInt(vSocketNumber);
            if (num_socket > 2)
                return "Standard";
            else if (num_socket > 0)
                return "Standard One";
            else {
                if (!isNull(log)) {
                    log.warn("Oracle Database Edition unknown because incomplete discovery data, pls. check the discovered socket number.");
                }
                return "";
            }
        } else {
            return vDbEdition;
        }
    }

    public static int getLMSOptionStatus(String optionName, List<String> optionsInUse) {
        if (optionsInUse.contains(optionName)) {
            return LMS_OPTIONS_STATUS_IN_USE;
        }
        return LMS_OPTIONS_STATUS_INSTALLED;
    }

    public static int getLMSPacksStatus(String packName, List<String> packsAgreed) {
        if (packsAgreed.contains(packName)) {
            return LMS_PACKS_STATUS_AGREED;
        }
        return LMS_PACKS_STATUS_GRANTED;
    }

    public static String getOracleFolder(String vLMS_OVERVIEW) {
        String machineId = getValueFromStringCsv(vLMS_OVERVIEW, LMS_MACHINE_ID_HEADER);
        String virtualMachineId = getValueFromStringCsv(vLMS_OVERVIEW, LMS_VIRTUAL_MACHINE_ID_HEADER);
        String dbName = getValueFromStringCsv(vLMS_OVERVIEW, LMS_DB_NAME_HEADER);
        return machineId + (fIsEmpty(virtualMachineId) ? "" : "/" + virtualMachineId) + (fIsEmpty(dbName) ? "" : "/" + dbName);
    }

    public static String getOracleEditionShortName(String vDbEdition) {
        if (fIsEmpty(vDbEdition)) {
            return "";
        } else if (vDbEdition.equalsIgnoreCase("Enterprise")) {
            return "ENT";
        } else if (vDbEdition.equalsIgnoreCase("Standard")) {
            return "STD";
        } else if (vDbEdition.equalsIgnoreCase("Standard One")) {
            return "STDONE";
        } else {
            throw new MessageOnlyPushMappingException("Unknown Oracle DB edition [" + vDbEdition + "]\r\nIf this is a valid edition it should be added to the getOracleEditionShortName groovy functions");
        }
    }

    public static def validateCsvExists(def docContent, def externalId) {
        if (fIsEmpty(docContent)) {
            throw new MessageOnlyPushMappingException('\r\n A CI [' + nicelyPrintExternalId(externalId) + '] Does not have CSV document content.', FAILED_MAPPING_CI_ERROR_ID);
        }
        return docContent;
    }

    public static boolean fIsSAIValid(def vInventoryKeyId) {
        if (fIsEmpty(vInventoryKeyId)) {
            return false;
        }
        String strKeyId = vInventoryKeyId;
        long keyId = Long.parseLong(strKeyId);
        if (keyId < 1500000000) {
            return true;
        } else {
            return false;
        }
    }

    public static def getClusterLayer(String CIType) {
        def result = 0;
        switch (CIType) {
            case FAILOVER_CLUSTER:
                result = 0;
                break;
            case LOAD_BALANCING_CLUSTER:
                result = 0;
                break;
            case EMC_AUTOSTART_CLUSTER:
                result = 0;
                break;
            case HACMP_CLUSTER:
                result = 2;
                break;
            case IBM_MQ_CLUSTER:
                result = 0;
                break;
            case MS_CLUSTER:
                result = 2;
                break;
            case SERVICE_GUARD_CLUSTER:
                result = 0;
                break;
            case SUN_CLUSTER:
                result = 2;
                break;
            case VERITAS_CLUSTER:
                result = 2;
                break;
            case VMWARE_CLUSTER:
                result = 2;
                break;
            case APACHE_TOMCAT_CLUSTER:
                result = 0;
                break;
            case J2EE_CLUSTER:
                result = 0;
                break;
            case MS_NLB_CLUSTER:
                result = 2;
                break;
            case ORACLE_RAC:
                result = 0;
                break;
            default:
                result = 0;
        }
        return result;
    }

    public static def getClusterType(String CIType) {
        def result = 0;
        switch (CIType) {
            case FAILOVER_CLUSTER:
                result = 0;
                break;
            case LOAD_BALANCING_CLUSTER:
                result = 1;
                break;
            case EMC_AUTOSTART_CLUSTER:
                result = 0;
                break;
            case HACMP_CLUSTER:
                result = 0;
                break;
            case IBM_MQ_CLUSTER:
                result = 0;
                break;
            case MS_CLUSTER:
                result = 0;
                break;
            case SERVICE_GUARD_CLUSTER:
                result = 0;
                break;
            case SUN_CLUSTER:
                result = 0;
                break;
            case VERITAS_CLUSTER:
                result = 0;
                break;
            case VMWARE_CLUSTER:
                result = 0;
                break;
            case APACHE_TOMCAT_CLUSTER:
                result = 1;
                break;
            case J2EE_CLUSTER:
                result = 1;
                break;
            case MS_NLB_CLUSTER:
                result = 1;
                break;
            case ORACLE_RAC:
                result = 1;
                break;
            default:
                result = 0;
        }
        return result;

    }

    public static String getClusterTechnology(String CIType) {
        return CIType;
    }

    public static String getClusterModelName(String CIType, String version) {
        String result = CIType;
        if (!fIsEmpty(version)) {
            result = result + " " + version;
        }
        result = toSmart(result.replaceAll("_", " "));
        return result;
    }

    /**
     In the UCMDB, like enum type, you only get key not value using "Root['os_family']" 
     or "Root.cpu[0]['cpu_specifier']";
     About enum type in the UCMDB, there are two types, int and string of enum,
     os_family is string enum but cpu_specifier is int enum.
     Pay attention to adding column which you needed in the TQL.

     e.g.
     <variable name="vCPUSpecifier" datatype="STRING" value="AMPush.getEnumValueByKey(ClassModel,Root.cpu[0]['cpu_specifier'],'cpu_specifier_enum')"/>
     <variable name="vOsFamily" datatype="STRING" value="AMPush.getEnumValueByKey(ClassModel,Root['os_family'],'os_family_enum')"/>
     <after-mapping>Logger.debug('vCPUSpecifier:'+vCPUSpecifier);Logger.debug('vOsFamily:'+vOsFamily)</after-mapping> 
     */
    public static String getEnumValueByKey(def ClassModel, def enumKey, String enumName) {
        def result = "";
        if (ClassModel.getEnumDefinitions().getStringEnum(enumName) != null) {
            result = enumKey;
        } else {
            Collection<EnumEntry> enumColl = ClassModel.getEnumDefinitions().getIntEnum(enumName).getEntries();
            for (EnumEntry enumElement : enumColl) {
                String key = enumElement.getKey();
                if (String.valueOf(enumKey).equals(key)) {
                    result = enumElement.getValue();
                    break;
                }
            }
        }
        return result;
    }

    // Get Max length value from param, temporary think it's most reliable
    // When param include 'Xeon', return 'Intel Xeon' for SAM caculation
    public static String getCpuType(def cpu_specifier, def cpu_type, def cpu_name) {

        if (isNull(cpu_specifier)) cpu_specifier = "";
        if (isNull(cpu_type)) cpu_type = "";
        if (isNull(cpu_name)) cpu_name = "";

        def cpuList = [cpu_specifier, cpu_type, cpu_name].sort { -it.length() };

        if (fIsContainList(cpuList, 'Xeon')) {
            return "Intel Xeon";
        } else {
            return cpuList[0];
        }

    }

    // Get Max length value from param, temporary think it's most reliable
    // Normlized CPU only for Intel Xeon
    public static String getCpuInternal(def cpu_specifier, def cpu_type, def cpu_name) {

        if (isNull(cpu_specifier)) cpu_specifier = "";
        if (isNull(cpu_type)) cpu_type = "";
        if (isNull(cpu_name)) cpu_name = "";

        def cpuList = [cpu_specifier, cpu_type, cpu_name].sort { -it.length() };

        return getNormalizedCPU(cpuList[0]);

    }

    // proc: CPU Mode
    // lpar: Lpar Mode
    // vp: online_virtual_cpu (Virtual Processor)
    // ec: entitled_capacity
    // only when CPU mode is shared, and Lpar mode is capped, CPU max is the value of EC, else is VP
    public static def getCpuMax(def proc, def lpar, def vp, def ec) {
        if (!fIsEmpty(proc) && !fIsEmpty(lpar)) {
            if (proc.equals("shared") && containsIgnoreCase(lpar.trim(), "uncapped"))
                return vp;
            else if (proc.equals("shared") && containsIgnoreCase(lpar.trim(), "capped"))
                return ec;
            else if (proc.equals("dedicated")
                    && (containsIgnoreCase(lpar.trim(), "capped")
                    || containsIgnoreCase(lpar.trim(), "uncapped")
                    || containsIgnoreCase(lpar.trim(), "donating")))
                return vp;
        }
        return null;
    }

    // When Node is ZOS, return VMType = ZOS
    // When Node has relationship with Virtual Host Resource, check root_class
    // Return LPAR or XEN for SAM caculation
    // Others return a meaningful Upper case string by root_class
    public static String getVMType(String rootClass, String nodeRootClass) {
        if (nodeRootClass == 'zos')
            return "ZOS";

        if (isNull(rootClass)) {
            return null;
        } else {
            switch (rootClass) {
                case 'ibm_lpar_profile':
                    return "LPAR";
                case 'xen_domain_config':
                    return "XEN";
                default:
                    return rootClass
                            .replaceAll("_", " ")
                            .replaceAll("config", "")
                            .replaceAll("resource", "")
                            .replaceAll("group", "")
                            .toUpperCase()
                            .trim();
            }

        }
    }

    // Check AM and SAM versions to ensure specified fields in AM DB 
    private static def isReadyForPVU() {
        String am_version = "9.50";
        String sam_version = "9.4.12.3";

        return isMatchVersion(am_version, sam_version);
    }

    // Check AM and SAM versions to ensure specified fields in AM DB 
    private static def isReadyForBDNA() {
        String am_version = "9.50";
        String sam_version = "9.4.12.5";

        return isMatchVersion(am_version, sam_version);
    }

    // Check Os_family, if it's windows, return first param, else return second
    public static String checkWindows(def first, def second, def classModel, def vOsFamily) {
        if ("windows".equals(getEnumValueByKey(classModel, vOsFamily, "os_family_enum"))) {
            return first;
        } else {
            return second;
        }
    }

    // Convert UCMDB CI's Owner Tenant to specified AM Tenant's ID
    private static def getAMTenantID(def dynamicMapHolder, def ownerTenant) {

        if (ENABLE_PUSH_MT) {
            if (fIsEmpty(ownerTenant)) return null; // Or return specified Tenant ID

            def amTenantCode = mtMapForPush[ownerTenant];
            def amTenantMap = dynamicMapHolder.getMap("TenantIdByCode");
            // TenantIdByCode is the dynamic mapping name that defined in mapping for caching AM Tanent Code and Tenant Id

            if (!isNull(amTenantMap)) return amTenantMap.get(amTenantCode);
        }

        return null;

    }

    //Find Audio / Sound device
    public static String getAudioAdapter(def hardware_board_name) {
        if (hardware_board_name.size() == 0) {
            return null;
        } else {

            // Search the list of hardware_board_names for the word Audio
            def hwList = hardware_board_name.findIndexOf { it ==~ /.*(Audio).*/ };

            // If the word Audio is not found, then search the list of hardware_board_names for the word Sound
            if (hwList == -1) {
                hwList = hardware_board_name.findIndexOf { it ==~ /.*(Sound).*/ };
            }
            // If neither are found, return null
            if (hwList == -1) {
                return null;
            } else {
                return hardware_board_name[hwList];
                //return hardware_board_name;
            }
        }
    }

    //Find Graphics / Video device
    public static String getVideoAdapter(def hardware_board_name, def ci_type) {
        if (hardware_board_name.size() == 0) {
            return null;
        } else {

            // if we have a CI in the list of CI types that has graphics_adapter in its name then return the first hardware_board_name
            def ci_list = ci_type.findIndexOf { it ==~ /.*graphics_adapter.*/ };
            if (ci_list != -1) {
                return hardware_board_name[ci_list];
            }

            // otherwise search the available hardware_board_names for Video, if not found then search for Graphics
            def hwList = hardware_board_name.findIndexOf { it ==~ /.*Video.*/ };
            if (hwList == -1) {
                hwList = hardware_board_name.findIndexOf { it ==~ /.*Graphics.*/ };
            }
            // if neither are found then return null
            if (hwList == -1) {
                return null;
            } else {
                return hardware_board_name[hwList];
            }
        }
    }

    // change processor pool containing "None" into null values
    private static def isProcessorPool(def value) {
        if ("None".equals(value)) {
            return "";
        }
        return value;
    }

    // PRIMARY return 0 "Owner"
    // PHYSICAL STANDBY or LOGICAL STANDBY return 1 "Standby"
    // return 99 "Other"
    public static def getClusterCompRole(def databaseRole) {
        if (fIsEmpty(databaseRole)) {
            return 99;
        } else if (containsIgnoreCase(databaseRole, "PRIMARY")) {
            return 0; // Owner
        } else if (containsIgnoreCase(databaseRole, "STANDBY")) {
            return 1; // Standby
        } else {
            return 99;
        }
    }

    // ResourceOption predefine in AssetManager, the values can be:
    // CPU: Processor
    //
    public static String getResourceOptionCode(def root_class) {

        if (root_class == '')
            return "";

        switch (root_class) {

            case 'ibm_resource_pool':

                return "CPU";
            default:
                return "";
        }

        return "";
    }

    public static def calcNumInUsed(def value1, def value2) {
        if (value1 != null && value2 != null)
            return value1 - value2;
        return 0;
    }

    public static String filterStandbyOptions(def databaseRole, def currentvalue) {
        if (databaseRole == "PRIMARY") {
            return currentvalue;
        }
        return null;
    }

    public static def getPrimaryOptions(def databaseRole, def root, def primary) {
        if (databaseRole != "PRIMARY" && !fIsEmpty(primary)) {
            return primary;
        }
        return root;
    }

}