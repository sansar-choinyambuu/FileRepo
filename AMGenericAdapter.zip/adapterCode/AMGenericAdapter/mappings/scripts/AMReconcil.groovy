package mappings.scripts

import com.hp.amadapter.api.AMApiWrapper
import com.hp.amadapter.push.structure.TreeNode
import com.hp.ucmdb.adapters.push.MessageOnlyPushMappingException
import com.hp.ucmdb.adapters.push.output.TypeValue
import org.w3c.dom.Document
import org.xml.sax.InputSource
import org.xml.sax.SAXException

import javax.xml.parsers.DocumentBuilder
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.parsers.ParserConfigurationException
import java.text.SimpleDateFormat

/**
 * User: cohenben
 * Date: 09/02/12
 * Time: 11:55
 */

public class AMReconcil extends AMUtils {

    public static final int NOT_EXIST = -1;
    // To assign-0 To be validated-1 Value accepted-2 Value rejected-3 Invalid-4 Obsolete-5
    public static final String SE_STATUS_TO_ASSIGN_STR = "To assign";
    public static final String SE_STATUS_TO_BE_VALIDATED_STR = "To be validated";
    public static final String SE_STATUS_VALUE_ACCEPTED_STR = "Value accepted";
    public static final String SE_STATUS_VALUE_REJECTED_STR = "Value rejected";
    public static final String SE_STATUS_INVALID_STR = "Invalid";
    public static final String SE_STATUS_OBSOLETE_STR = "Obsolete";
    public static final String NO_FURTHER_NOTIFICATIONS = "1";
    public static final int INDEX_OFFSET = 1;
    public static final String DATE_FORMAT_TO_AM = "#yyyy-MM-dd HH:mm:ss#";
    public static final String DATE_FORMAT_FROM_AM = "yyyy-MM-dd HH:mm:ss";
    private static final DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();

    public static boolean isDateAfter(def newDate, def oldDate){
        // The new scan date shouldn't be null unless it wasn't added to the layout.
        if(fIsEmpty(newDate) || fIsEmpty(oldDate)){
            return true;
        }
        GregorianCalendar gregorianCalendar = new GregorianCalendar();
        gregorianCalendar.setTime(oldDate);
        if (newDate.after(gregorianCalendar)){
            return true;
        }
        return false;
    }

    public static updateMemorySize(AMApiWrapper apiWrapper, def newVal, def oldVal, def PrimaryKey, def outputCI){
        def assetTag = outputCI.getVariable("vAssetTag").getValue();
        Calendar dtHardScan = outputCI.getVariable("vDtHardScan").getValue();
        def computerName = outputCI.getVariable("vComputerName").getValue();
        def strCode = "CPU_MEM_" + assetTag;
        def path = "lMemorySizeMb";
        def recordTable = "amComputer";
        if(!isNull(dtHardScan)){
            strCode = strCode +" "+ dtHardScan.getTime();
        }
        def strName = "The memory of the computer "+computerName+" has decreased.";
        if(fIsEmpty(newVal)){
            return oldVal;
        }
        if(fIsEmpty(oldVal) || newVal >= oldVal){
            return newVal;
        }
        return validateReconcUpdateAdvance(apiWrapper, newVal, oldVal, PrimaryKey, strCode, strName, path, recordTable);
    }

    public static def validateReconcUpdateAdvance(AMApiWrapper apiWrapper, def newVal, def oldVal, def recordId,
                                                  def strCode, def strName, def path, def recordTable){
        String stmt = "Select lReconcPropId, ProposedValue, seStatus, NewValue, OldValue, bNoFurtherNotif"+
                " FROM amReconcProposal WHERE RecordTable='"+recordTable+"' AND lRecordId=" + recordId +
                " AND Path='"+path+"'  AND NOT(seStatus=4) AND NOT (seStatus=5)";
        String stmtResult = apiWrapper.selectAQL("", stmt);
        Document document = stringToDom(stmtResult);
        def retVal = oldVal;
        if(!isResultEmpty(document)){
            def seStatus = getValueByName(document, "seStatus");
            def recNewValue = getValueByName(document, "NewValue");
            def recOldValue = getValueByName(document, "OldValue");
            def recPropId = getValueByName(document, "lReconcPropId");

            if(seStatus == SE_STATUS_TO_ASSIGN_STR || seStatus == SE_STATUS_TO_BE_VALIDATED_STR){
                if(recNewValue == newVal && recOldValue == oldVal){
                    //OldValue and NewValue are both with same value
                    //Don't apply value for the field
                    return retVal;
                }
                else{
                    setReconcProposalObsolete(apiWrapper, recPropId);
                    createReconcProposalAdvance(apiWrapper, strCode, strName, newVal, oldVal, recordId, path, recordTable);
                }
            }

            else if(seStatus == SE_STATUS_VALUE_ACCEPTED_STR || seStatus == SE_STATUS_VALUE_REJECTED_STR){
                //The proposal is accepted or rejected
                def bNoFurtherNotif = getValueByName(document, "bNoFurtherNotif");
                if(recNewValue == newVal && recOldValue == oldVal && bNoFurtherNotif == NO_FURTHER_NOTIFICATIONS){
                    //OldValue and NewValue are both with same value and IgnoreFutherNotifs =1
                    if(seStatus == SE_STATUS_VALUE_ACCEPTED_STR){
                        // The proposition has been validated, get the value
                        retVal = getValueByName(document, "ProposedValue");
                    }
                    else if(seStatus == SE_STATUS_VALUE_REJECTED_STR){
                        // Don't apply value for the field
                        return retVal;
                    }
                }
                else{
                    // Invalidate old reconciliation proposal
                    setReconcProposalInvalidate(apiWrapper, recPropId);
                    // Create a reconciliation proposal
                    createReconcProposalAdvance(apiWrapper, strCode, strName,  newVal, oldVal, recordId, path, recordTable);
                }
            }
        }
        else{
            //There is no proposal. Create a reconciliation proposal
            createReconcProposalAdvance(apiWrapper, strCode, strName, newVal, oldVal, recordId, path, recordTable);
        }
        return retVal;
    }

    static boolean isResultEmpty(Document document) {
        org.w3c.dom.NodeList resultRowList = document.getElementsByTagName("Row");
        if(resultRowList == null || resultRowList.length == 0){
            return true;
        }
        return false;
    }

    static void setReconcProposalObsolete(AMApiWrapper apiWrapper, def recPropId) {
        def currDate = getCurrDate();
        String stmt = "UPDATE amReconcProposal SET seStatus ='"+SE_STATUS_OBSOLETE_STR+"', dtObsolete="+currDate+"  WHERE lReconcPropId = "+ recPropId+"";
        System.out.println stmt;
        apiWrapper.execAql("", stmt);
    }


    // creates new reconciliation proposal with the new values. By default seStatus is 'to assign'.
    static void createReconcProposalAdvance(AMApiWrapper apiWrapper, def strCode, def strName, def vNewVal, def vOldVal, def vOldId, def path, def recordTable){
        def stmt = "INSERT INTO amReconcProposal (Code, Name, RecordTable, Path, NewValue, OldValue, lRecordId)";
        def date = getCurrDateLong();
        String uniqueCode = strCode + " "+date;
        stmt = stmt + " VALUES ('"+uniqueCode+"','" + strName +"', '"+recordTable+"' , '"+path+"' ,'" +vNewVal +"','"+ vOldVal+ "'," + vOldId+ ")";
        apiWrapper.execAql("", stmt);
    }

    static void setReconcProposalInvalidate(AMApiWrapper apiWrapper, def recPropId){
        def currDate = getCurrDate();
        def stmt = "UPDATE amReconcProposal SET seStatus = '"+SE_STATUS_INVALID_STR+"', dtInvalid = "+currDate+" WHERE lReconcPropId = " + recPropId;
        apiWrapper.execAql("", stmt);
    }


    public static Document stringToDom(String xmlSource){
        DocumentBuilder builder;
        Document result;
        try {
            builder = documentBuilderFactory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        }
        try {
            result =  builder.parse(new InputSource(new StringReader(xmlSource)));
        } catch (SAXException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return result;
    }

    private static String getValueByIndex(org.w3c.dom.Node rowResult, int index){
        if(rowResult == null){
            return null;
        }
        org.w3c.dom.NodeList childNodesResult = rowResult.getChildNodes();
        String resultVal = null;
        if(childNodesResult != null){
            int realIndex = index + INDEX_OFFSET;
            org.w3c.dom.Node currColumn = childNodesResult.item(realIndex);
            if(currColumn != null){
                resultVal = currColumn.getTextContent();
            }
        }
        return resultVal;
    }

    private static String getValueByName(Document document, String colName){
        org.w3c.dom.NodeList schemaList = document.getElementsByTagName("Schema");
        String result = null;
        if(schemaList != null){
            org.w3c.dom.Node schemaNode = schemaList.item(0);
            int index = getIndexByName(schemaNode, colName);
            if(index != NOT_EXIST){
                org.w3c.dom.NodeList resultRowList = document.getElementsByTagName("Row");
                if(resultRowList != null){
                    org.w3c.dom.Node resultRowNode = resultRowList.item(0);
                    result = getValueByIndex(resultRowNode, index);
                }
            }
        }
        return result;
    }

    private static int getIndexByName(org.w3c.dom.Node schema, String colName){
        org.w3c.dom.NodeList childNodesResult = schema.getChildNodes();
        if(childNodesResult != null){
            for(int i=0; i<childNodesResult.getLength(); i++){
                org.w3c.dom.Node childNode = childNodesResult.item(i);
                if(childNode != null && childNode.getAttributes() != null){
                    org.w3c.dom.Node colNameNode = childNode.getAttributes().getNamedItem("Name");
                    if(colNameNode != null){
                        if(colName.equals(colNameNode.getTextContent())){
                            return i;
                        }
                    }
                }
            }
        }
        return NOT_EXIST;
    }


    private static long getCurrDateLong(){
        Date currDate = new java.util.Date();
        return currDate.getTime();
    }

    private static String getCurrDate(){
        Date currDate = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_TO_AM);
        return sdf.format(currDate);
    }

    public static String getShortHostName(String strFullHostName){
        if(isNull(strFullHostName)){
            return null;
        }
        int dotIndex = strFullHostName.indexOf(".");
        if(dotIndex > -1){
            strFullHostName = strFullHostName.substring(0, dotIndex);
        }
        return strFullHostName;
    }

    public static int getModelFromInstalledSoftwareCI(TreeNode softwareRTN) {
        List<TreeNode> iModels = softwareRTN.getChildrenByName('Complete_amInventModel');
        if (iModels.size() != 1) {
            throw new MessageOnlyPushMappingException("Installed Software should have only one InventModel Child");
        }
        TreeNode inventModel = iModels.iterator().next();
        TypeValue typeValue = inventModel.getProperty("lModelFinalId");
        int lModelFinalIdValue = Integer.parseInt(typeValue.getValue().toString());
        if (lModelFinalIdValue <= 0) {
            TypeValue tmpValue = inventModel.getProperty('lModelTmpId');
            int lModelTmpIdValue = Integer.parseInt(tmpValue.getValue().toString());
            return lModelTmpIdValue;
        } else {
            return lModelFinalIdValue;
        }

    }

    //This function transforms a string to be used in a query.
    //All single quotes (') are doubled
    public static String getSqlTextConst(String str){
        if(isNull(str)){
            return null;
        }
        return str.replaceAll("'", "''");
    }

}