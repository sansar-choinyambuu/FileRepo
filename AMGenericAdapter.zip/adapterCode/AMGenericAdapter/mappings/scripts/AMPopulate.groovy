package mappings.scripts

import com.hp.ucmdb.federationspi.adapter.logging.DataAdapterLogger
import org.apache.commons.lang.StringUtils

public class AMPopulate extends AMUtils {

    private static DataAdapterLogger log;
    private static String hostIsDesktop = "Windows desktop computer,Unix desktop computer,Desktop computers";
    private static String hostIsNotDesktop = "Smart phone,Mainframe CPC,Virtual Machine,Windows computer,VMware VirtualCenter,VMware ESX Server,Unix server computer,Solaris Zone Server,Unknown server,Computer servers,Laptop,Mainframe,ATM switch,Firewall,Router,Switch,Network printer,ADSL Modem,Appletalk Gateway,Bandwidth Manager,Cable modem,CSU_DSU,Ethernet,FDDI,HUB,KVM Switch,Load Balancer,Multicast Enabled Router,NAT Router,Token Ring,Undefined Network Component,VoIP Gateway,VoIP Switch,VPN Gateway,Wireless Access Point,Frame Relay Switch,SAN Gateway,SAN Router,SAN Switch,PDA Handheld,Storage Array,Mainframe Logical Partition";
    private static String hostIsVirtual = "Virtual Machine,Mainframe Logical Partition";
    private static String hostIsNotVirtual = "Smart phone,Mainframe CPC,Windows computer,Windows desktop computer,VMware VirtualCenter,VMware ESX Server,Unix server computer,Unix desktop computer,Solaris Zone Server,Desktop computers,Computer servers,Laptop,Mainframe,ATM switch,Firewall,Router,Switch,Network printer,ADSL Modem,Appletalk Gateway,Bandwidth Manager,Cable modem,CSU_DSU,Ethernet,FDDI,HUB,KVM Switch,Load Balancer,Multicast Enabled Router,NAT Router,Token Ring,Undefined Network Component,VoIP Gateway,VoIP Switch,VPN Gateway,Wireless Access Point,Frame Relay Switch,SAN Gateway,SAN Router,SAN Switch,PDA Handheld,Storage Array";

    private static Map<String, String> assignments = new HashMap<String, String>();
    private static Map<Integer, String> contractStauts = new HashMap<Integer, String>();
    private static Map<Integer, String> expenseTypes = new HashMap<Integer, String>();
    private static Map<String, String> locationTypes = new HashMap<String, String>();
    private static Map<String, String> kpiComparisonOperators = new HashMap<String, String>();
    private static Map<String, String> ipAddressProps = new HashMap<String, String>();
    private static List<String[]> hostDataCIList = new ArrayList<String[]>();
    private static List<String[]> businessElementCIList = new ArrayList<String[]>();
    // Node roles
    private static Map<String, String> nodeRoles = new HashMap<String, String>();
    private static Map<Integer, String> clientResourceStates = new HashMap<Integer, String>();

    static {
        // Node roles
        nodeRoles.put("Computer servers", "server");
        nodeRoles.put("Unix server computer", "server");
        nodeRoles.put("Windows computer", "server");
        nodeRoles.put("VMware ESX Server", "server");
        nodeRoles.put("Solaris Zone server", "server");

        nodeRoles.put("Desktop computers", "desktop");
        nodeRoles.put("Computer", "desktop");
        nodeRoles.put("Laptop", "desktop");
        nodeRoles.put("Windows desktop computer", "desktop");
        nodeRoles.put("Unix desktop computer", "desktop");

        nodeRoles.put("Virtual Machine", "virtualized_system");
        nodeRoles.put("Network printer", "printer");
        nodeRoles.put("Firewall", "firewall");
        nodeRoles.put("ATM switch", "atm_switch");
        nodeRoles.put("Router", "router");
        nodeRoles.put("Gateway", "gateway");
        nodeRoles.put("Modem", "modem");
        nodeRoles.put("Switch", "lan_switch");
        nodeRoles.put("Ethernet", "ethernet");
        nodeRoles.put("Hub", "hub");
        nodeRoles.put("Token Ring", "token_ring");
        nodeRoles.put("Wireless Access Point", "wireless_access_point");
        nodeRoles.put("VPN Gateway", "vpn_gateway");
        nodeRoles.put("Appletalk Gateway", "appletalk_gateway");
        nodeRoles.put("VoIP Gateway", "voice_gateway");
        nodeRoles.put("VoIP Switch", "voice_switch");
        nodeRoles.put("", "traffic_redirector");
        nodeRoles.put("Bandwidth Manager", "bandwidth_manager");
        nodeRoles.put("KVM Switch", "kvm_switch");
        nodeRoles.put("CSU_DSU", "csu_dsu");
        nodeRoles.put("Cable modem", "cable_modem");
        nodeRoles.put("NAT Router", "nat_router");
        nodeRoles.put("SAN Gateway", "san_gateway");
        nodeRoles.put("ADSL Modem", "adsl_model");
        nodeRoles.put("Frame Relay Switch", "frame_relay_switch");
        nodeRoles.put("Multicast Enabled Router", "multicast_enabled_router");
        nodeRoles.put("Load Balancer", "load_balancer");
        nodeRoles.put("SAN Switch", "san_switch");
        nodeRoles.put("SAN Router", "san_router");
        nodeRoles.put("Undefined Network component", "undefined_network_component");
        nodeRoles.put("FDDI", "fddi");
        nodeRoles.put("PDA Handheld", "pda_handheld");

        // *** Key: AM value, Value: UCMDB value ***
        // assignments <-- assignment_transformer.xml
        assignments.put("0", "in-use");
        assignments.put("1", "in-stock");
        assignments.put("2", "missing");
        assignments.put("3", "awaiting-receipt");
        assignments.put("4", "returned-for-maintenance");
        assignments.put("5", "returned-to-supplier");
        assignments.put("6", "missing");

        // contractStauts <-- contract_status_transformer.xml
        contractStauts.put("0", "in_preparation");
        contractStauts.put("1", "standard_contract");
        contractStauts.put("11", "quote_requested");
        contractStauts.put("12", "quoted");
        contractStauts.put("13", "awaiting_approval");
        contractStauts.put("14", "validated");
        contractStauts.put("15", "denied");
        contractStauts.put("31", "active");
        contractStauts.put("33", "awaiting_approval_for_renewal");
        contractStauts.put("39", "suspended");
        contractStauts.put("41", "finished");
        contractStauts.put("-1", "canceled");

        // locationTypes <-- location_type_transformer.xml
        locationTypes.put("site", "site");
        locationTypes.put("building", "building");
        locationTypes.put("floor", "floor");
        locationTypes.put("room", "room");
        locationTypes.put("Data Center", "room");
        locationTypes.put("", "undefined");

        // kpiComparisonOperators <-- kpi_comparison_operator_transformer.xml
        kpiComparisonOperators.put("&lt;", "&lt;");
        kpiComparisonOperators.put("&lt;=", "&lt;=");
        kpiComparisonOperators.put("=", "=");
        kpiComparisonOperators.put("&gt;", "&gt;");
        kpiComparisonOperators.put("&gt;=", "&gt;=");

        // ipAddressProps <-- ip_address_property_transformer.xml
        ipAddressProps.put("anycast", "anycast");
        ipAddressProps.put("broadcast", "broadcast");
        ipAddressProps.put("dhcp", "dhcp");
        ipAddressProps.put("loopback", "loopback");

        // expenseTypes <-- expensetype_transformer.xml
        // amCostCategory
        expenseTypes.put("0", "capex");
        expenseTypes.put("1", "opex");

        clientResourceStates.put("0", "In Preparation");
        clientResourceStates.put("1", "Awaiting Approval");
        clientResourceStates.put("2", "Approved");
        clientResourceStates.put("3", "In Service");
        clientResourceStates.put("4", "Out of Service");
        clientResourceStates.put("5", "Retired");

        // Host data CI
        hostDataCIList.add(["host_node", "Computer,Desktop computers,Computer servers,Laptop,Virtual Machine,Smart phone"]);
        hostDataCIList.add(["nt", "Windows computer,Windows desktop computer,VMware VirtualCenter"]);
        hostDataCIList.add(["unix", "Unix server computer,Unix desktop computer,Solaris Zone server"]);
        hostDataCIList.add(["vmware_esx_server", "VMware ESX Server"]);
        hostDataCIList.add(["mainframe", "Mainframe,Mainframe CPC"]);
        hostDataCIList.add(["lpar", "Mainframe Logical Partition"]);

        hostDataCIList.add(["firewall", "Firewall"]);
        hostDataCIList.add(["router", "Router"]);
        hostDataCIList.add(["switch", "Switch"]);
        hostDataCIList.add(["atmswitch", "ATM switch"]);
        hostDataCIList.add(["netprinter", "Network printer"]);
        hostDataCIList.add(["netdevice", "ADSL Modem,Appletalk Gateway,Bandwidth Manager,Cable modem,CSU_DSU,Ethernet,FDDI,HUB,KVM Switch,Load Balancer,Multicast Enabled Router,NAT Router,Token Ring,Undefined Network Component,VoIP Gateway,VoIP Switch,VPN Gateway,Wireless Access Point,Frame Relay Switch,SAN Gateway,SAN Router,SAN Switch,PDA Handheld"]);
        hostDataCIList.add(["storagearray", "Storage Array"]);

        // Business_Element
        businessElementCIList.add(["business_service", "BIZSVC"]);
        businessElementCIList.add(["infrastructure_service", "INFRASVC"]);
        businessElementCIList.add(["business_application", "BIZAPP"]);
    }

    private static boolean isDebugEnabled() {
        return log != null && log.isDebugEnabled();
    }

    public static void setLog(def logger) {
        log = logger;
    }

    public static String getNodeType(String vmType, String natureName, String natureComputerType, String defaultComputerType) {
        if ("3".equals(natureComputerType) && "LPAR".equalsIgnoreCase(vmType))
            return "Mainframe Logical Partition";
        else if ("Storage Provider".equalsIgnoreCase(natureName))
            return "Storage Array";
        return defaultComputerType;
    }

    public static Boolean isDesktop(String computerType) {
        if (computerType != null && containsIgnoreCase(hostIsNotDesktop, computerType))
            return false;
        if (computerType != null && containsIgnoreCase(hostIsDesktop, computerType))
            return true;
        return null;
    }

    public static Boolean isVirtual(String computerType) {
        if (computerType != null && containsIgnoreCase(hostIsNotVirtual, computerType))
            return false;
        if (computerType != null && containsIgnoreCase(hostIsVirtual, computerType))
            return true;
        return null;
    }

    public static String getAssignment(String assignment) {
        return assignments.get(assignment);
    }

    public static String getIpAddressValue(String subnetMask, String tcpIpAddress) {
        if (subnetMask == null || "".equals(subnetMask))
        // Both IPv6 and IPv4 address values are kept in an IPv6 address format from UCMDB property comments
            return tcpIpAddress;
        return tcpIpAddress + "/ " + subnetMask;
    }

    public static boolean isValidIp(String ipAddress) {
        if (ipAddress == null || "".equals(ipAddress))
            return false;
        return true;
    }

    public static String convertIpAddressProperty(String bDHCPEnabled) {
        if ("1".equals(bDHCPEnabled))
            return "dhcp";
        return null;
    }

    public static String getLocationType(String locationType) {
        return locationTypes.get(locationType);
    }

    public static String getKpiComparisonOperator(String kpiComparisonOperator) {
        return kpiComparisonOperators.get(kpiComparisonOperator);
    }

    public static String getIpAddressProperty(String ipAddressProp) {
        return ipAddressProps.get(ipAddressProp);
    }

    public static String getNodeRole(String nodeRole) {
        String ucmdbNodeRole = nodeRoles.get(nodeRole);

        if (!fIsEmpty(ucmdbNodeRole))
            return ucmdbNodeRole;

        else if (!fIsEmpty(nodeRole))
            return nodeRole.trim().replaceAll(" ", "_").toLowerCase();

        else
            return "1876543210"; // default empty role

    }

    public static boolean isValidLocationParent(def locationParent) {
        if (locationParent['lLocaId'] != 0
                && locationParent['BarCode'] != null
                && !"".equals(locationParent['BarCode']))
            return true;
        return false;
    }

    public static String getCRState(String state) {
        return clientResourceStates.get(state);
    }

    public static String getHostDataCI(String computerType) {
        String hostCI = "node";
        if (computerType != null) {
            for (String[] CI : hostDataCIList) {
                if (CI[1].contains(computerType)) {
                    hostCI = CI[0];
                    break;
                }
            }
        }
        if (isDebugEnabled())
            log.debug("Host CI: " + hostCI);
        return hostCI;
    }

    public static String getServiceClass(String code) {
        if (code != null) {
            for (String[] CI : businessElementCIList) {
                if (CI[1].contains(code))
                    return CI[0];
            }
        }
        // TODO If the incoming Nature Code doesn't exist in the business element CI type mapping,
        // TODO customer should set the correct service class, if not set, adapter will give the default "business_service"
        return "business_service";
    }

    /**
     * 1. dtRecCreation is after lastSyncTime and status is not "in-use" or "in-stock" ---> is-delete and is-valid
     * 2. dtRecCreation is after lastSyncTime and status is "in-use" or "in-stock" --> not-delete and is-valid
     * 3. dtRecCreation is before lastSyncTime and status is "in-use" or "in-stock" --> not-delete and is-valid
     * 4. dtRecCreation is before lastSyncTime and status is not "in-use" or "in-stock" ---> not-delete and is-not-valid --> is-not-valid
     * @param assignment
     * @param dtRecCreation
     * @param lastSyncTime
     * @return
     */
    public static Boolean isValidNode(String assignment, Date dtRecCreation, Date lastSyncTime) {
        String assign = assignments.get(assignment);
        if (compareDate(dtRecCreation, lastSyncTime) < 0 && !("in-use".equals(assign) || "in-stock".equals(assign)))
            return false;
        return true;
    }

    public static Boolean isDeletedNode(String assignment, Date dtRecCreation, Date lastSyncTime) {
        if (compareDate(dtRecCreation, lastSyncTime) < 0)
            return false;
        String assign = assignments.get(assignment);
        if ("in-use".equals(assign) || "in-stock".equals(assign))
            return false;
        return true;
    }
    /**
     * It is used to check the Node RTN is valid and is not for deletion
     * @param assignment
     * @param dtRecCreation
     * @param lastSyncTime
     * @return
     */
    public static Boolean isAcceptableNode(String assignment, Date dtRecCreation, Date lastSyncTime) {
        return isValidNode(assignment, dtRecCreation, lastSyncTime) &&
                !isDeletedNode(assignment, dtRecCreation, lastSyncTime);
    }

    /**
     * busineness element status is decided by amAsset's Status field. By default the Status field in AM is empty
     * The script function uses a default 'retired' value for amAsset's Status field value here.
     * If user want to use another value, the script must be modified.
     * @param status
     * @return
     */
    public static Boolean isDeletedBusinessElement(String status) {
        if ("retired".equals(status))
            return true;
        return false;
    }
    
    public static boolean isContainment(String name, boolean isBE) {
        return StringUtils.containsIgnoreCase(name, "Containment") && isBE;
    }

    public static boolean isUsage(String name, boolean isBE) {
        return StringUtils.containsIgnoreCase(name, "Usage") && isBE;
    }

    // Convert AM Tenant Code to UCMDB Owner Tenant
    private static def getOwnerTenant(def TenantCode){
		def defaultOwnerTenant = "";  // Or specified UCMDB Tenant Name
		
		if (ENABLE_POP_MT){
			if (fIsEmpty(TenantCode))  return defaultOwnerTenant;
			else{
				def tenantName = mtMapForPop[TenantCode]
				return isNull(tenantName) ? defaultOwnerTenant : tenantName;
			}
		}
		
		return defaultOwnerTenant;
    }   
}